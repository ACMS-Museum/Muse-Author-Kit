"""Evennia command adapter for MuseLang3 scenario verbs."""

from __future__ import annotations

from datetime import datetime

from evennia import CmdSet
from evennia.server.models import ServerConfig
from commands.command import Command

from .runtime import RuntimeContext, RuntimeScriptError, apply_state_defaults, execute_interaction


BEHAVIOUR_PATH = "behaviours.muselang.scenario_verbs.ScenarioVerbCmdSet"


class _WorldAttributes:
    def get(self, key, category=None):
        return ServerConfig.objects.conf(f"muselang.world.{key}", default=None)

    def add(self, key, value, category=None):
        ServerConfig.objects.conf(f"muselang.world.{key}", value=value)

    def remove(self, key, category=None):
        ServerConfig.objects.conf(f"muselang.world.{key}", delete=True)


class _WorldState:
    key = "world"
    attributes = _WorldAttributes()


WORLD_STATE = _WorldState()


def _read(obj, key, default):
    attributes = getattr(obj, "attributes", None)
    if attributes is None:
        return default
    value = attributes.get(key, category="muse3")
    return default if value is None else value


def _write(obj, key, value):
    attributes = getattr(obj, "attributes", None)
    if attributes is not None:
        attributes.add(key, value, category="muse3")


def _strip_target(text, obj):
    words = (text or "").strip().split()
    tokens = {str(getattr(obj, "key", "")).casefold()}
    aliases = getattr(obj, "aliases", None)
    if aliases is not None and callable(getattr(aliases, "all", None)):
        tokens.update(str(item).casefold() for item in aliases.all())
    if words and words[0].casefold() in tokens:
        words.pop(0)
    if words and words[-1].casefold() in tokens:
        words.pop()
    return " ".join(words)


def _make_command(interaction, routines, defaults):
    verb = str(interaction.get("verb") or interaction.get("id"))
    class CmdScenarioVerb(Command):
        def func(self):
            now = datetime.now().astimezone()
            team = getattr(getattr(self.caller, "db", None), "muselang_team", None)
            context = RuntimeContext(
                caller=self.caller, obj=self.obj, verb=verb, routines=routines,
                scenario=self.obj, team=team, world=WORLD_STATE,
                real_values={"now": now, "date": now.date(), "time": now.time()},
                random_seed=_read(self.obj, "random_seed", 0),
                initial_random_state=_read(self.obj, "random_state", None),
            )
            apply_state_defaults(defaults, context)
            try:
                execute_interaction(interaction, context, _strip_target(self.args, self.obj))
                _write(self.obj, "random_state", context.rng.getstate())
            except RuntimeScriptError as exc:
                self.caller.msg(str(exc))
    CmdScenarioVerb.__name__ = "Cmd" + "".join(part.title() for part in verb.split("_"))
    CmdScenarioVerb.key = verb
    CmdScenarioVerb.aliases = list(interaction.get("aliases", []))
    CmdScenarioVerb.help_category = "Scenario"
    return CmdScenarioVerb


class ScenarioVerbCmdSet(CmdSet):
    key = "MuseLang3ScenarioVerbCmdSet"
    priority = 1
    def at_cmdset_creation(self):
        obj = self.cmdsetobj
        if obj is None:
            return
        routines = _read(obj, "routines", {})
        defaults = _read(obj, "state_defaults", [])
        for interaction in _read(obj, "interactions", []):
            if interaction.get("behaviour") == BEHAVIOUR_PATH:
                self.add(_make_command(interaction, routines, defaults)())
