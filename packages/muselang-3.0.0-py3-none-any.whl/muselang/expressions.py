"""Parse and validate the restricted MuseLang3 expression language."""

from __future__ import annotations

import ast
import re
from typing import Any, Iterator

from .errors import ParseError
from .model import Expr, SourceSpan, Template


SAFE_FUNCTIONS = {
    "min", "max", "abs", "clamp", "round", "floor", "ceil",
    "random_int", "random_chance", "random_choice", "size",
}


def parse_expression(text: str, span: SourceSpan) -> Expr:
    source = text.strip()
    if source.startswith("have "):
        name = source[5:].strip()
        if not re.fullmatch(r"[A-Za-z_][\w-]*", name):
            raise ParseError(f"{span.location}: invalid object in 'have' predicate")
        return {"kind": "predicate", "name": "have", "args": [{"kind": "reference", "path": name}]}
    try:
        node = ast.parse(source, mode="eval").body
    except SyntaxError as exc:
        column = span.column + max(0, (exc.offset or 1) - 1)
        raise ParseError(f"{span.path}:{span.line}:{column}: invalid expression: {exc.msg}") from None
    return _convert(node, span)


def _convert(node: ast.AST, span: SourceSpan) -> Expr:
    if isinstance(node, ast.Constant) and isinstance(node.value, (str, bool, int, float)):
        return {"kind": "literal", "value": node.value}
    if isinstance(node, ast.Name):
        if node.id in {"true", "false"}:
            return {"kind": "literal", "value": node.id == "true"}
        return {"kind": "reference", "path": node.id}
    if isinstance(node, ast.Attribute):
        return {"kind": "reference", "path": _attribute_path(node, span)}
    if isinstance(node, ast.Subscript):
        target = _subscript_target(node.value, span)
        indices = _subscript_indices(node.slice, span)
        return {"kind": "array", "path": target, "indices": indices}
    if isinstance(node, ast.UnaryOp) and isinstance(node.op, (ast.Not, ast.USub)):
        return {"kind": "unary", "op": "not" if isinstance(node.op, ast.Not) else "-", "operand": _convert(node.operand, span)}
    if isinstance(node, ast.BinOp) and isinstance(node.op, (ast.Add, ast.Sub, ast.Mult, ast.Div, ast.FloorDiv, ast.Mod)):
        operators = {ast.Add: "+", ast.Sub: "-", ast.Mult: "*", ast.Div: "/", ast.FloorDiv: "//", ast.Mod: "%"}
        return {"kind": "binary", "op": operators[type(node.op)], "left": _convert(node.left, span), "right": _convert(node.right, span)}
    if isinstance(node, ast.BoolOp) and isinstance(node.op, (ast.And, ast.Or)):
        op = "and" if isinstance(node.op, ast.And) else "or"
        values = [_convert(value, span) for value in node.values]
        result = values[0]
        for value in values[1:]:
            result = {"kind": "binary", "op": op, "left": result, "right": value}
        return result
    if isinstance(node, ast.Compare) and len(node.ops) == 1 and len(node.comparators) == 1:
        operators = {ast.Eq: "==", ast.NotEq: "!=", ast.Gt: ">", ast.GtE: ">=", ast.Lt: "<", ast.LtE: "<="}
        op = operators.get(type(node.ops[0]))
        if op:
            return {"kind": "binary", "op": op, "left": _convert(node.left, span), "right": _convert(node.comparators[0], span)}
    if isinstance(node, ast.Call) and isinstance(node.func, ast.Name) and node.func.id in SAFE_FUNCTIONS and not node.keywords:
        return {"kind": "call", "name": node.func.id, "args": [_convert(arg, span) for arg in node.args]}
    raise ParseError(f"{span.location}: expression form {type(node).__name__} is not allowed")


def _attribute_path(node: ast.Attribute, span: SourceSpan) -> str:
    parts = [node.attr]
    current: ast.AST = node.value
    while isinstance(current, ast.Attribute):
        parts.append(current.attr)
        current = current.value
    if not isinstance(current, ast.Name):
        raise ParseError(f"{span.location}: invalid state reference")
    parts.append(current.id)
    return ".".join(reversed(parts))


def _subscript_target(node: ast.AST, span: SourceSpan) -> str:
    if isinstance(node, ast.Name):
        return node.id
    if isinstance(node, ast.Attribute):
        return _attribute_path(node, span)
    raise ParseError(f"{span.location}: invalid array reference")


def _subscript_indices(node: ast.AST, span: SourceSpan) -> list[Expr]:
    items = node.elts if isinstance(node, ast.Tuple) else [node]
    if not items:
        raise ParseError(f"{span.location}: array reference requires at least one index")
    return [_convert(item, span) for item in items]


def parse_template(text: str, span: SourceSpan) -> Template:
    result: Template = []
    literal: list[str] = []
    index = 0
    while index < len(text):
        if text.startswith("{{", index):
            literal.append("{")
            index += 2
            continue
        if text.startswith("}}", index):
            literal.append("}")
            index += 2
            continue
        if text[index] == "}":
            raise ParseError(f"{span.location}: unmatched '}}' in interpolated string")
        if text[index] != "{":
            literal.append(text[index])
            index += 1
            continue
        if literal:
            result.append({"kind": "text", "value": "".join(literal)})
            literal = []
        end = text.find("}", index + 1)
        if end < 0:
            raise ParseError(f"{span.location}: unmatched '{{' in interpolated string")
        source = text[index + 1:end].strip()
        if not source:
            raise ParseError(f"{span.location}: empty interpolation")
        result.append({"kind": "expression", "value": parse_expression(source, span)})
        index = end + 1
    if literal or not result:
        result.append({"kind": "text", "value": "".join(literal)})
    return result


def walk_expression(expr: Expr) -> Iterator[Expr]:
    yield expr
    kind = expr.get("kind")
    if kind == "unary":
        yield from walk_expression(expr["operand"])
    elif kind == "binary":
        yield from walk_expression(expr["left"])
        yield from walk_expression(expr["right"])
    elif kind == "array":
        for index in expr.get("indices", []):
            yield from walk_expression(index)
    elif kind in {"call", "predicate"}:
        for arg in expr.get("args", []):
            yield from walk_expression(arg)
