"""MuseLang3 diagnostics."""


class MuseLang3Error(Exception):
    """Base error reported to an author."""


class ParseError(MuseLang3Error):
    """Invalid source syntax."""


class ValidationError(MuseLang3Error):
    """Invalid resolved program."""


class RuntimeScriptError(MuseLang3Error):
    """Safe scenario execution failure."""
