"""Semantic validation for MuseLang3."""

from __future__ import annotations

from typing import Any

from .errors import ValidationError
from .expressions import SAFE_FUNCTIONS
from .model import ArrayDecl, Document, Expr, NounDef, Statement


ARGUMENT_TYPES = {"int", "float", "number", "string", "word", "bool", "object", "room", "char", "id"}
NAMESPACE_ROOTS = {"this", "player", "team", "game", "scenario", "world", "real"}
RESERVED = NAMESPACE_ROOTS | SAFE_FUNCTIONS | {"true", "false", "and", "or", "not"}
BUILTIN_TYPES = {"thing", "device", "container", "supporter", "door", "key", "portable_item"}


def validate_document(document: Document) -> list[str]:
    warnings: list[str] = []
    nouns: dict[str, NounDef] = {}
    rooms: set[str] = set()
    goals: set[str] = set()
    for noun in document.nouns:
        if noun.noun_id in nouns:
            _fail(noun.span.location, f"duplicate noun id {noun.noun_id!r}")
        nouns[noun.noun_id] = noun
        if noun.kind == "room":
            rooms.add(noun.noun_id)
    for goal in document.goals:
        if goal.goal_id in goals:
            _fail(goal.span.location, f"duplicate goal id {goal.goal_id!r}")
        goals.add(goal.goal_id)
    seen_defaults: set[str] = set()
    for default in document.state_defaults:
        root = default.target.split(".", 1)[0]
        if root not in {"player", "team", "game", "scenario", "world"}:
            _fail(default.span.location, f"invalid state namespace {root!r}")
        canonical = default.target.replace("game.", "scenario.", 1)
        if canonical in seen_defaults:
            _fail(default.span.location, f"duplicate state declaration {canonical!r}")
        seen_defaults.add(canonical)
    seen_arrays: set[str] = set()
    global_arrays: dict[str, ArrayDecl] = {}
    for default in document.array_defaults:
        root = default.target.split(".", 1)[0]
        if root not in {"player", "team", "game", "scenario", "world"}:
            _fail(default.span.location, f"invalid array namespace {root!r}")
        canonical = default.target.replace("game.", "scenario.", 1)
        if canonical in seen_defaults or canonical in seen_arrays:
            _fail(default.span.location, f"duplicate state declaration {canonical!r}")
        seen_arrays.add(canonical)
        global_arrays[canonical] = default
        _validate_array_decl(default)
    for noun in document.nouns:
        if noun.kind in {"object", "character"} and noun.location not in rooms:
            _fail(noun.span.location, f"unknown room {noun.location!r}")
        if noun.type_id and noun.type_id not in BUILTIN_TYPES and noun.type_id not in nouns:
            _fail(noun.span.location, f"unknown type {noun.type_id!r}")
        if len({alias.casefold() for alias in noun.aliases}) != len(noun.aliases):
            _fail(noun.span.location, "duplicate aliases")
        _validate_noun(noun, nouns, goals, global_arrays)
    return warnings


def _validate_noun(noun: NounDef, nouns: dict[str, NounDef], goals: set[str], global_arrays: dict[str, ArrayDecl]) -> None:
    for name, array in noun.arrays.items():
        if name in noun.state:
            _fail(array.span.location, f"duplicate state declaration {name!r}")
        _validate_array_decl(array)
    routines = {routine.name: routine for routine in noun.routines}
    if len(routines) != len(noun.routines):
        _fail(noun.span.location, "duplicate routine name")
    verbs: set[str] = set()
    for verb in noun.verbs:
        if verb.name in verbs:
            _fail(verb.span.location, f"duplicate verb {verb.name!r}")
        verbs.add(verb.name)
        argument_names: set[str] = set()
        for argument in verb.arguments:
            if argument.type_name not in ARGUMENT_TYPES:
                _fail(argument.span.location, f"unknown argument type {argument.type_name!r}")
            if argument.name in argument_names or argument.name in RESERVED:
                _fail(argument.span.location, f"invalid or duplicate argument name {argument.name!r}")
            argument_names.add(argument.name)
        for argument in verb.arguments[:-1]:
            if argument.optional or argument.type_name == "string":
                _fail(argument.span.location, "optional and string arguments must be last")
        _validate_program(verb.statements, noun, nouns, goals, routines, set(argument_names), set(), global_arrays)
    graph: dict[str, set[str]] = {name: set() for name in routines}
    for routine in noun.routines:
        _validate_program(routine.statements, noun, nouns, goals, routines, set(), set(), global_arrays)
        for statement in _walk_statements(routine.statements):
            if statement.op == "run" and "." not in statement.data["target"]:
                graph[routine.name].add(statement.data["target"])
    _check_cycles(graph, noun)


def _validate_program(
    statements: list[Statement], noun: NounDef, nouns: dict[str, NounDef], goals: set[str],
    routines: dict[str, Any], arguments: set[str], locals_in: set[str], global_arrays: dict[str, ArrayDecl],
) -> None:
    locals_here = set(locals_in)
    arrays = _array_symbols(noun, nouns, global_arrays)
    for statement in statements:
        location = statement.span.location
        if statement.op == "let":
            name = statement.data["name"]
            if name in RESERVED or name in arguments or name in locals_here or name in nouns:
                _fail(location, f"invalid or duplicate local name {name!r}")
            _validate_expression(statement.data["value"], noun, nouns, arguments, locals_here, arrays, location)
            locals_here.add(name)
        elif statement.op == "set":
            target = statement.data["target"]
            if target["kind"] == "reference":
                path = str(target["path"])
                if path.startswith("real."):
                    _fail(location, "real.* is read-only")
                if "." not in path:
                    if path in arguments:
                        _fail(location, f"argument {path!r} is read-only")
                    if path not in locals_here:
                        _fail(location, f"unknown local variable {path!r}")
                else:
                    _validate_state_target(path, noun, nouns, location)
            else:
                _validate_array_target(target, noun, nouns, arguments, locals_here, arrays, location)
            _validate_expression(statement.data["value"], noun, nouns, arguments, locals_here, arrays, location)
        elif statement.op in {"say", "hint"}:
            for part in statement.data["template"]:
                if part["kind"] == "expression":
                    _validate_expression(part["value"], noun, nouns, arguments, locals_here, arrays, location)
        elif statement.op == "if":
            for branch in statement.data["branches"]:
                _validate_expression(branch["condition"], noun, nouns, arguments, locals_here, arrays, location)
                _validate_program(branch["program"], noun, nouns, goals, routines, arguments, locals_here, global_arrays)
            _validate_program(statement.data["else"], noun, nouns, goals, routines, arguments, locals_here, global_arrays)
        elif statement.op == "for":
            name = statement.data["name"]
            if name in RESERVED or name in arguments or name in nouns:
                _fail(location, f"invalid loop variable {name!r}")
            _validate_expression(statement.data["start"], noun, nouns, arguments, locals_here, arrays, location)
            _validate_expression(statement.data["end"], noun, nouns, arguments, locals_here, arrays, location)
            _validate_expression(statement.data["step"], noun, nouns, arguments, locals_here, arrays, location)
            if statement.data["step"].get("kind") == "literal" and statement.data["step"].get("value") == 0:
                _fail(location, "step must not be zero")
            body_locals = set(locals_here)
            body_locals.add(name)
            _validate_program(statement.data["program"], noun, nouns, goals, routines, arguments, body_locals, global_arrays)
            locals_here.add(name)
        elif statement.op == "run":
            target = statement.data["target"]
            if "." not in target:
                if target not in routines:
                    _fail(location, f"unknown routine {target!r}")
            else:
                owner, routine_name = target.split(".", 1)
                if owner == "this":
                    owner = noun.noun_id
                if owner not in nouns:
                    _fail(location, f"unknown routine owner {owner!r}")
                elif routine_name not in {item.name for item in nouns[owner].routines}:
                    _fail(location, f"unknown routine {target!r}")
        elif statement.op == "achieve" and statement.data["goal"] not in goals:
            _fail(location, f"unknown goal {statement.data['goal']!r}")
        elif statement.op == "move":
            if statement.data["object"] != "player" and statement.data["object"] not in nouns:
                _fail(location, f"unknown move object {statement.data['object']!r}")
            if statement.data["location"] not in nouns:
                _fail(location, f"unknown move destination {statement.data['location']!r}")


def _validate_expression(
    expr: Expr, noun: NounDef, nouns: dict[str, NounDef], arguments: set[str], locals_: set[str],
    arrays: dict[str, ArrayDecl], location: str,
) -> None:
    kind = expr.get("kind")
    if kind == "literal":
        return
    if kind == "reference":
        path = str(expr["path"])
        if path in arrays:
            _fail(location, f"array {path!r} requires index access or size()")
        if "." not in path:
            if path not in arguments and path not in locals_ and path not in noun.state and path not in nouns:
                _fail(location, f"unknown value reference {path!r}")
            return
        root, field = path.split(".", 1)
        if root == "this" and field not in noun.state:
            _fail(location, f"unknown state reference {path!r}")
        if root in nouns and field not in nouns[root].state:
            _fail(location, f"unknown state reference {path!r}")
        if root not in NAMESPACE_ROOTS and root not in nouns:
            _fail(location, f"unknown namespace or object {root!r}")
        return
    if kind == "array":
        _validate_array_reference(expr, noun, nouns, arguments, locals_, arrays, location)
        return
    if kind == "unary":
        _validate_expression(expr["operand"], noun, nouns, arguments, locals_, arrays, location)
        return
    if kind == "binary":
        _validate_expression(expr["left"], noun, nouns, arguments, locals_, arrays, location)
        _validate_expression(expr["right"], noun, nouns, arguments, locals_, arrays, location)
        return
    if kind == "predicate":
        for arg in expr.get("args", []):
            _validate_expression(arg, noun, nouns, arguments, locals_, arrays, location)
        return
    if kind == "call":
        _validate_call(expr, noun, nouns, arguments, locals_, arrays, location)
        return


def _validate_call(
    expr: Expr, noun: NounDef, nouns: dict[str, NounDef], arguments: set[str], locals_: set[str],
    arrays: dict[str, ArrayDecl], location: str,
) -> None:
    name = expr["name"]
    count = len(expr.get("args", []))
    exact = {"abs": 1, "round": 1, "floor": 1, "ceil": 1, "clamp": 3, "random_int": 2, "random_chance": 1}
    if name in exact and count != exact[name]:
        _fail(location, f"{name} requires {exact[name]} argument(s)")
    if name in {"min", "max", "random_choice"} and count < 1:
        _fail(location, f"{name} requires at least one argument")
    if name == "size":
        if count not in {1, 2}:
            _fail(location, "size requires 1 or 2 argument(s)")
        target = expr["args"][0]
        if target.get("kind") != "reference" or _resolve_array_decl(str(target["path"]), noun, nouns, arrays) is None:
            _fail(location, "size requires an array name as its first argument")
        if count == 2:
            _validate_expression(expr["args"][1], noun, nouns, arguments, locals_, arrays, location)
        return
    if name == "random_chance" and expr["args"][0].get("kind") == "literal":
        value = expr["args"][0]["value"]
        if not isinstance(value, (int, float)) or not 0 <= value <= 100:
            _fail(location, "random_chance percentage must be between 0 and 100")
    for arg in expr.get("args", []):
        _validate_expression(arg, noun, nouns, arguments, locals_, arrays, location)


def _validate_state_target(target: str, noun: NounDef, nouns: dict[str, NounDef], location: str) -> None:
    root, field = target.split(".", 1)
    if root == "this" and field not in noun.state:
        _fail(location, f"assignment to undeclared state {target!r}")
    elif root in nouns and field not in nouns[root].state:
        _fail(location, f"assignment to undeclared state {target!r}")
    elif root not in NAMESPACE_ROOTS and root not in nouns:
        _fail(location, f"unknown assignment target {root!r}")


def _array_symbols(noun: NounDef, nouns: dict[str, NounDef], global_arrays: dict[str, ArrayDecl]) -> dict[str, ArrayDecl]:
    result = dict(global_arrays)
    result.update(noun.arrays)
    for other_name, other in nouns.items():
        for array_name, array in other.arrays.items():
            result[f"{other_name}.{array_name}"] = array
    return result


def _validate_array_decl(array: ArrayDecl) -> None:
    if not array.dimensions:
        _fail(array.span.location, "array declarations require at least one dimension")
    if any(not isinstance(size, int) or isinstance(size, bool) or size <= 0 for size in array.dimensions):
        _fail(array.span.location, "array dimensions must be positive integers")


def _validate_array_reference(
    expr: Expr, noun: NounDef, nouns: dict[str, NounDef], arguments: set[str], locals_: set[str],
    arrays: dict[str, ArrayDecl], location: str,
) -> None:
    path = str(expr["path"])
    array = _resolve_array_decl(path, noun, nouns, arrays)
    if array is None:
        _fail(location, f"unknown array reference {path!r}")
    if len(expr.get("indices", [])) != len(array.dimensions):
        _fail(location, f"array {path!r} requires {len(array.dimensions)} index value(s)")
    for index in expr.get("indices", []):
        _validate_expression(index, noun, nouns, arguments, locals_, arrays, location)


def _validate_array_target(
    expr: Expr, noun: NounDef, nouns: dict[str, NounDef], arguments: set[str], locals_: set[str],
    arrays: dict[str, ArrayDecl], location: str,
) -> None:
    path = str(expr["path"])
    if path.startswith("real."):
        _fail(location, "real.* is read-only")
    _validate_array_reference(expr, noun, nouns, arguments, locals_, arrays, location)


def _resolve_array_decl(path: str, noun: NounDef, nouns: dict[str, NounDef], arrays: dict[str, ArrayDecl]) -> ArrayDecl | None:
    array = arrays.get(path)
    if array is not None:
        return array
    if "." not in path:
        return None
    root, field = path.split(".", 1)
    if root == "this":
        return noun.arrays.get(field)
    if root in nouns:
        return nouns[root].arrays.get(field)
    if root == "game":
        return arrays.get(path.replace("game.", "scenario.", 1))
    return None


def _walk_statements(statements: list[Statement]):
    for statement in statements:
        yield statement
        if statement.op == "if":
            for branch in statement.data["branches"]:
                yield from _walk_statements(branch["program"])
            yield from _walk_statements(statement.data["else"])


def _check_cycles(graph: dict[str, set[str]], noun: NounDef) -> None:
    visiting: set[str] = set()
    visited: set[str] = set()
    def visit(name: str):
        if name in visiting:
            _fail(noun.span.location, f"recursive routine call involving {name!r}")
        if name in visited:
            return
        visiting.add(name)
        for child in graph.get(name, set()):
            visit(child)
        visiting.remove(name)
        visited.add(name)
    for name in graph:
        visit(name)


def _fail(location: str, message: str) -> None:
    raise ValidationError(f"{location}: {message}")
