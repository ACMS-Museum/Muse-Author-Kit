"""MuseLang 3 compiler and bounded scenario runtime."""

__version__ = "3.0.0"
