"""Emit an Evennia batch file from a MuseLang3 bundle."""

from __future__ import annotations

from typing import Any


def emit_batch(bundle: dict[str, Any]) -> str:
    nouns = bundle.get("nouns", [])
    rooms = [noun for noun in nouns if noun.get("kind") == "room"]
    others = [noun for noun in nouns if noun.get("kind") != "room"]
    lines: list[str] = []
    def emit(command: str) -> None:
        lines.extend((command, "#"))
    for room in rooms:
        emit(f"@dig {_name(room)};{_aliases(room)}")
        emit(f"@tel me = {room['id']}")
        _definition(room, emit)
    for noun in others:
        emit(f"@create {_name(noun)};{_aliases(noun)}")
        _definition(noun, emit)
        emit(f"@tel {noun['id']} = {noun['location']}")
    return "\n".join(lines).rstrip() + "\n"


def _definition(noun: dict[str, Any], emit) -> None:
    noun_id = noun["id"]
    if noun.get("description"):
        emit(f"@desc {'here' if noun['kind'] == 'room' else noun_id} = {noun['description']}")
    for key, value in (noun.get("state") or {}).items():
        emit(f"set {noun_id}/{key}:muse3 = {value!r}")
    for key in ("interactions", "routines", "state_defaults"):
        value = noun.get(key)
        if value:
            emit(f"set {noun_id}/{key}:muse3 = {value!r}")
    for behaviour in noun.get("required_behaviours", []):
        emit(f'py self.search("{noun_id}").cmdset.add("{behaviour}", persistent=True)')


def _name(noun: dict[str, Any]) -> str:
    return str(noun.get("name") or noun["id"])


def _aliases(noun: dict[str, Any]) -> str:
    return ";".join(dict.fromkeys([str(noun["id"]), *(str(item) for item in noun.get("aliases", []))]))
