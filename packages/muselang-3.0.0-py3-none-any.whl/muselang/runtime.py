"""Safe, deterministic interpreter for MuseLang3 structured metadata."""

from __future__ import annotations

import math
import random
import shlex
from dataclasses import dataclass, field
from decimal import Decimal, ROUND_HALF_UP
from typing import Any, Callable

from .errors import RuntimeScriptError


CALL_HANDLERS: dict[str, Callable[["RuntimeContext"], None]] = {}


def register_call_handler(name: str, handler: Callable[["RuntimeContext"], None]) -> None:
    CALL_HANDLERS[name] = handler


@dataclass(slots=True)
class RuntimeContext:
    caller: Any
    obj: Any
    verb: str = ""
    raw_args: str = ""
    scenario: Any | None = None
    team: Any | None = None
    world: Any | None = None
    objects: dict[str, Any] = field(default_factory=dict)
    real_values: dict[str, Any] = field(default_factory=dict)
    locals: dict[str, Any] = field(default_factory=dict)
    routines: dict[str, list[dict[str, Any]]] = field(default_factory=dict)
    achievements: set[str] = field(default_factory=set)
    random_seed: int = 0
    max_call_depth: int = 32
    call_depth: int = 0
    messages: list[str] = field(default_factory=list)
    mutations: list[dict[str, Any]] = field(default_factory=list)
    random_results: list[Any] = field(default_factory=list)
    initial_random_state: Any | None = None
    _undo: list[tuple[Any, ...]] = field(default_factory=list, repr=False)
    rng: random.Random = field(init=False, repr=False)

    def __post_init__(self) -> None:
        self.rng = random.Random(self.random_seed)
        if self.initial_random_state is not None:
            self.rng.setstate(self.initial_random_state)
        if self.obj is not None:
            self.objects.setdefault(str(getattr(self.obj, "key", "this")), self.obj)

    def replay_record(self) -> dict[str, Any]:
        return {
            "verb": self.verb,
            "arguments": dict(self.locals),
            "random_seed": self.random_seed,
            "random_results": list(self.random_results),
            "mutations": list(self.mutations),
            "messages": list(self.messages),
            "achievements": sorted(self.achievements),
        }


def execute_interaction(interaction: dict[str, Any], context: RuntimeContext, raw_args: str = "") -> dict[str, Any]:
    message_start = len(context.messages)
    mutation_start = len(context.mutations)
    random_start = len(context.random_results)
    undo_start = len(context._undo)
    achievement_start = set(context.achievements)
    rng_start = context.rng.getstate()
    context.verb = str(interaction.get("verb") or interaction.get("id") or "")
    context.raw_args = raw_args
    try:
        context.locals = bind_arguments(interaction.get("arguments", []), raw_args, context)
        if interaction.get("routines"):
            context.routines = dict(interaction["routines"])
        result = execute_program(interaction.get("program", []), context)
    except Exception:
        for undo in reversed(context._undo[undo_start:]):
            if undo[0] == "state":
                _, owner, field, previous = undo
                if previous is _MISSING:
                    _delete_state(owner, field)
                else:
                    _write_state(owner, field, previous)
            elif undo[0] == "move":
                _, obj, previous = undo
                move_to = getattr(obj, "move_to", None)
                if callable(move_to):
                    move_to(previous, quiet=True)
        del context.messages[message_start:]
        del context.mutations[mutation_start:]
        del context.random_results[random_start:]
        del context._undo[undo_start:]
        context.achievements.clear()
        context.achievements.update(achievement_start)
        context.rng.setstate(rng_start)
        raise
    sender = getattr(context.caller, "msg", None)
    if callable(sender):
        for message in context.messages[message_start:]:
            sender(message)
    del context._undo[undo_start:]
    return result


def bind_arguments(definitions: list[dict[str, Any]], raw_args: str, context: RuntimeContext) -> dict[str, Any]:
    text = raw_args.strip()
    tokens = _argument_tokens(text)
    result: dict[str, Any] = {}
    cursor = 0
    for index, definition in enumerate(definitions):
        name = str(definition["name"])
        type_name = str(definition.get("type") or "word")
        optional = bool(definition.get("optional"))
        if type_name == "string":
            if cursor >= len(tokens):
                if optional:
                    result[name] = None
                    continue
                raise RuntimeScriptError(f"{context.verb.upper()} requires {name} (string).")
            result[name] = " ".join(tokens[cursor:])
            cursor = len(tokens)
            continue
        if cursor >= len(tokens):
            if optional:
                result[name] = None
                continue
            raise RuntimeScriptError(f"{context.verb.upper()} requires {name} ({type_name}).")
        token = tokens[cursor]
        cursor += 1
        try:
            result[name] = _convert_argument(token, type_name, context)
        except (TypeError, ValueError):
            raise RuntimeScriptError(f"{context.verb.upper()} requires {name} to be {type_name}.") from None
    if cursor < len(tokens):
        raise RuntimeScriptError(f"Too many arguments for {context.verb.upper()}.")
    return result


def execute_program(program: list[dict[str, Any]], context: RuntimeContext) -> dict[str, Any]:
    result = {"ended": False, "stopped": False}
    for step in program:
        op = step.get("op")
        if op == "if":
            selected = step.get("else", [])
            for branch in step.get("branches", []):
                if bool(evaluate_expression(branch["condition"], context)):
                    selected = branch.get("program", [])
                    break
            nested = execute_program(selected, context)
            if nested["ended"] or nested["stopped"]:
                return nested
        elif op == "let":
            context.locals[str(step["name"])] = evaluate_expression(step["value"], context)
        elif op == "set":
            _execute_set(step, context)
        elif op == "for":
            nested = _execute_for(step, context)
            if nested["ended"] or nested["stopped"]:
                return nested
        elif op in {"say", "hint"}:
            message = render_template(step.get("template", []), context)
            context.messages.append(message)
        elif op == "run":
            nested = _run_routine(str(step["target"]), context)
            if nested["ended"] or nested["stopped"]:
                return nested
        elif op == "achieve":
            goal = str(step["goal"])
            context.achievements.add(goal)
            existing = list(_read_state(context.caller, "achievements", []) or [])
            if goal not in existing:
                previous = _read_state(context.caller, "achievements", _MISSING)
                context._undo.append(("state", context.caller, "achievements", previous))
                existing.append(goal)
                _write_state(context.caller, "achievements", existing)
            context.mutations.append({"kind": "achieve", "goal": goal})
        elif op == "move":
            _move(str(step["object"]), str(step["location"]), context)
        elif op == "call":
            handler = CALL_HANDLERS.get(str(step["target"]))
            if handler is None:
                raise RuntimeScriptError(f"MuseLang3 call target {step['target']!r} is not registered")
            handler(context)
        elif op == "stop":
            return {"ended": False, "stopped": True}
        elif op == "end":
            return {"ended": True, "stopped": False}
        else:
            raise RuntimeScriptError(f"Unknown MuseLang3 opcode {op!r}")
    return result


def evaluate_expression(expr: dict[str, Any], context: RuntimeContext) -> Any:
    kind = expr.get("kind")
    if kind == "literal":
        return expr.get("value")
    if kind == "reference":
        return read_reference(str(expr["path"]), context)
    if kind == "array":
        indices = [evaluate_expression(index, context) for index in expr.get("indices", [])]
        return read_array_reference(str(expr["path"]), indices, context)
    if kind == "predicate" and expr.get("name") == "have":
        identifier = str(expr["args"][0]["path"]).casefold()
        return any(identifier in _object_tokens(item) for item in getattr(context.caller, "contents", []) or [])
    if kind == "unary":
        value = evaluate_expression(expr["operand"], context)
        return not bool(value) if expr["op"] == "not" else -_number(value)
    if kind == "binary":
        op = expr["op"]
        if op == "and":
            left = evaluate_expression(expr["left"], context)
            return bool(left) and bool(evaluate_expression(expr["right"], context))
        if op == "or":
            left = evaluate_expression(expr["left"], context)
            return bool(left) or bool(evaluate_expression(expr["right"], context))
        left = evaluate_expression(expr["left"], context)
        right = evaluate_expression(expr["right"], context)
        return _binary(op, left, right)
    if kind == "call":
        args = [evaluate_expression(arg, context) for arg in expr.get("args", [])]
        return _call_builtin(str(expr["name"]), args, context)
    raise RuntimeScriptError(f"Unknown expression kind {kind!r}")


def render_template(template: list[dict[str, Any]], context: RuntimeContext) -> str:
    parts: list[str] = []
    for part in template:
        if part.get("kind") == "text":
            parts.append(str(part.get("value", "")))
        else:
            parts.append(str(evaluate_expression(part["value"], context)))
    return "".join(parts)


def read_reference(path: str, context: RuntimeContext) -> Any:
    if "." not in path:
        if path in context.locals:
            return context.locals[path]
        return _read_state(context.obj, path)
    root, field = path.split(".", 1)
    if root == "real":
        return context.real_values.get(field)
    owner = _scope_owner(root, context)
    if owner is None:
        return None
    return _read_state(owner, field)


def apply_state_defaults(defaults: list[dict[str, Any]], context: RuntimeContext) -> None:
    for default in defaults:
        target = str(default["target"])
        root, field = target.split(".", 1)
        owner = _scope_owner(root, context)
        if owner is not None and _read_state(owner, field, _MISSING) is _MISSING:
            _write_state(owner, field, default.get("value"))


def _execute_set(step: dict[str, Any], context: RuntimeContext) -> None:
    target = step["target"]
    value = evaluate_expression(step["value"], context)
    assignment = str(step.get("assignment") or "=")
    if target["kind"] == "reference":
        path = str(target["path"])
        if "." not in path:
            current = context.locals.get(path)
            context.locals[path] = _assigned_value(assignment, current, value)
            return
        root, field = path.split(".", 1)
        if root == "real":
            raise RuntimeScriptError("real.* is read-only")
        owner = _scope_owner(root, context)
        if owner is None:
            raise RuntimeScriptError(f"Cannot resolve state owner {root!r}")
        previous = _read_state(owner, field)
        previous_for_undo = _read_state(owner, field, _MISSING)
        updated = _assigned_value(assignment, previous, value)
        context._undo.append(("state", owner, field, previous_for_undo))
        _write_state(owner, field, updated)
        context.mutations.append({"kind": "set", "target": path.replace("game.", "scenario.", 1), "before": previous, "after": updated})
        return
    indices = [evaluate_expression(index, context) for index in target.get("indices", [])]
    current = read_array_reference(str(target["path"]), indices, context)
    updated = _assigned_value(assignment, current, value)
    write_array_reference(str(target["path"]), indices, updated, context)


def _execute_for(step: dict[str, Any], context: RuntimeContext) -> dict[str, Any]:
    name = str(step["name"])
    start = int(_number(evaluate_expression(step["start"], context)))
    end = int(_number(evaluate_expression(step["end"], context)))
    increment = int(_number(evaluate_expression(step["step"], context)))
    if increment == 0:
        raise RuntimeScriptError("for step must not be zero")
    current = start
    while (increment > 0 and current <= end) or (increment < 0 and current >= end):
        context.locals[name] = current
        nested = execute_program(step.get("program", []), context)
        if nested["ended"] or nested["stopped"]:
            return nested
        current += increment
    context.locals[name] = current
    return {"ended": False, "stopped": False}


def _run_routine(target: str, context: RuntimeContext) -> dict[str, Any]:
    if context.call_depth >= context.max_call_depth:
        raise RuntimeScriptError("maximum routine call depth exceeded")
    owner = context.obj
    routines = context.routines
    name = target
    if "." in target:
        owner_name, name = target.split(".", 1)
        owner = _scope_owner(owner_name, context)
        routines = _read_state(owner, "routines", {}) if owner is not None else {}
    program = routines.get(name) if isinstance(routines, dict) else None
    if not isinstance(program, list):
        raise RuntimeScriptError(f"Unknown routine {target!r}")
    previous_obj, previous_locals, previous_depth, previous_routines = context.obj, context.locals, context.call_depth, context.routines
    context.obj = owner
    context.locals = dict(previous_locals)
    context.call_depth += 1
    context.routines = routines
    try:
        return execute_program(program, context)
    finally:
        context.obj, context.locals, context.call_depth, context.routines = previous_obj, previous_locals, previous_depth, previous_routines


def _move(object_name: str, location_name: str, context: RuntimeContext) -> None:
    obj = context.caller if object_name == "player" else _resolve_object(object_name, context)
    destination = _resolve_object(location_name, context)
    move_to = getattr(obj, "move_to", None) if obj is not None else None
    if not callable(move_to) or destination is None:
        raise RuntimeScriptError(f"Cannot move {object_name!r} to {location_name!r}")
    context._undo.append(("move", obj, getattr(obj, "location", None)))
    move_to(destination, quiet=True)
    context.mutations.append({"kind": "move", "object": object_name, "location": location_name})


def _call_builtin(name: str, args: list[Any], context: RuntimeContext) -> Any:
    if name == "min": return min(args)
    if name == "max": return max(args)
    if name == "abs": return abs(_number(args[0]))
    if name == "clamp": return min(max(args[0], args[1]), args[2])
    if name == "round": return int(Decimal(str(_number(args[0]))).quantize(Decimal("1"), rounding=ROUND_HALF_UP))
    if name == "floor": return math.floor(_number(args[0]))
    if name == "ceil": return math.ceil(_number(args[0]))
    if name == "random_int":
        value = context.rng.randint(int(args[0]), int(args[1]))
    elif name == "size":
        if not args:
            raise RuntimeScriptError("size requires an array value")
        dimension = 1 if len(args) == 1 else int(_number(args[1]))
        value = array_size(args[0], dimension)
    elif name == "random_chance":
        percent = float(args[0])
        if not 0 <= percent <= 100:
            raise RuntimeScriptError("random_chance percentage must be between 0 and 100")
        value = context.rng.random() * 100 < percent
    elif name == "random_choice":
        if not args:
            raise RuntimeScriptError("random_choice requires at least one value")
        value = args[context.rng.randrange(len(args))]
    else:
        raise RuntimeScriptError(f"Unknown built-in function {name!r}")
    context.random_results.append(value)
    return value


def _binary(op: str, left: Any, right: Any) -> Any:
    if op == "+": return _number(left) + _number(right)
    if op == "-": return _number(left) - _number(right)
    if op == "*": return _number(left) * _number(right)
    if op == "/": return _number(left) / _number(right)
    if op == "//": return _number(left) // _number(right)
    if op == "%": return _number(left) % _number(right)
    if op == "==": return left == right
    if op == "!=": return left != right
    if op == ">": return left > right
    if op == ">=": return left >= right
    if op == "<": return left < right
    if op == "<=": return left <= right
    raise RuntimeScriptError(f"Unknown binary operator {op!r}")


def _assigned_value(assignment: str, current: Any, value: Any) -> Any:
    if assignment == "=": return value
    if current is None:
        raise RuntimeScriptError("compound assignment requires an existing value")
    return _binary("+" if assignment == "+=" else "-", current, value)


def _number(value: Any) -> int | float:
    if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(float(value)):
        raise RuntimeScriptError(f"Expected a finite number, got {value!r}")
    return value


def _argument_tokens(text: str) -> list[str]:
    if not text:
        return []
    try:
        return shlex.split(text, posix=True)
    except ValueError as exc:
        raise RuntimeScriptError(f"Cannot parse command arguments: {exc}") from None


def _convert_argument(token: str, type_name: str, context: RuntimeContext) -> Any:
    if type_name == "int": return int(token)
    if type_name == "float": return float(token)
    if type_name == "number": return float(token) if any(char in token for char in ".eE") else int(token)
    if type_name == "bool":
        if token.casefold() not in {"true", "false"}: raise ValueError(token)
        return token.casefold() == "true"
    if type_name in {"word", "string", "id"}: return token
    if type_name in {"object", "room", "char"}:
        obj = _resolve_object(token, context)
        if obj is None: raise ValueError(token)
        return obj
    raise ValueError(type_name)


def _scope_owner(root: str, context: RuntimeContext) -> Any | None:
    if root == "this": return context.obj
    if root in {"player", "caller"}: return context.caller
    if root in {"scenario", "game"}: return context.scenario or context.obj
    if root == "team": return context.team
    if root == "world": return context.world
    return _resolve_object(root, context)


def _resolve_object(name: str, context: RuntimeContext) -> Any | None:
    if name in context.objects:
        return context.objects[name]
    lowered = name.casefold()
    for candidate in [context.obj, context.caller, *(getattr(context.caller, "contents", []) or []), *(getattr(getattr(context.caller, "location", None), "contents", []) or [])]:
        if candidate is not None and lowered in _object_tokens(candidate):
            return candidate
    search = getattr(context.caller, "search", None)
    if callable(search):
        found = search(name, global_search=True, quiet=True)
        if isinstance(found, (list, tuple)):
            return found[0] if len(found) == 1 else None
        return found
    return None


def _object_tokens(obj: Any) -> set[str]:
    tokens = {str(getattr(obj, "key", "")).casefold()}
    aliases = getattr(obj, "aliases", None)
    if aliases is not None and callable(getattr(aliases, "all", None)):
        tokens.update(str(item).casefold() for item in aliases.all())
    return tokens


_MISSING = object()


def _read_state(obj: Any, key: str, default: Any = None) -> Any:
    if obj is None: return default
    if isinstance(obj, dict): return obj.get(key, default)
    attributes = getattr(obj, "attributes", None)
    if attributes is not None and callable(getattr(attributes, "get", None)):
        value = attributes.get(key, category="muse3")
        if value is not None: return value
    db = getattr(obj, "db", None)
    value = getattr(db, key, None) if db is not None else None
    return default if value is None else value


def _write_state(obj: Any, key: str, value: Any) -> None:
    if isinstance(obj, dict):
        obj[key] = value
        return
    attributes = getattr(obj, "attributes", None)
    if attributes is not None and callable(getattr(attributes, "add", None)):
        attributes.add(key, value, category="muse3")
        return
    db = getattr(obj, "db", None)
    if db is None:
        raise RuntimeScriptError(f"Cannot write state {key!r}")
    setattr(db, key, value)


def _delete_state(obj: Any, key: str) -> None:
    if isinstance(obj, dict):
        obj.pop(key, None)
        return
    attributes = getattr(obj, "attributes", None)
    if attributes is not None and callable(getattr(attributes, "remove", None)):
        attributes.remove(key, category="muse3")
        return
    if attributes is not None and hasattr(attributes, "values"):
        attributes.values.pop(("muse3", key), None)
        return
    db = getattr(obj, "db", None)
    if db is not None and hasattr(db, key):
        delattr(db, key)


def read_array_reference(path: str, indices: list[Any], context: RuntimeContext) -> Any:
    owner, field = _resolve_array_owner(path, context)
    array = _read_state(owner, field)
    if array is None:
        raise RuntimeScriptError(f"Unknown array {path!r}")
    descriptor = _array_descriptor(array, path)
    return _array_get(descriptor, indices, path)


def write_array_reference(path: str, indices: list[Any], value: Any, context: RuntimeContext) -> None:
    owner, field = _resolve_array_owner(path, context)
    array = _read_state(owner, field, _MISSING)
    if array is _MISSING:
        raise RuntimeScriptError(f"Unknown array {path!r}")
    descriptor = _array_descriptor(array, path)
    previous_state = _clone_array_descriptor(descriptor)
    previous_value = _array_get(descriptor, indices, path)
    _array_set(descriptor, indices, value, path)
    context._undo.append(("state", owner, field, previous_state))
    _write_state(owner, field, descriptor)
    context.mutations.append({"kind": "set", "target": path.replace("game.", "scenario.", 1), "before": previous_value, "after": value})


def array_size(array: Any, dimension: int) -> int:
    descriptor = _array_descriptor(array, "size()")
    if dimension < 1 or dimension > len(descriptor["dimensions"]):
        raise RuntimeScriptError("size dimension is out of range")
    return int(descriptor["dimensions"][dimension - 1])


def _resolve_array_owner(path: str, context: RuntimeContext) -> tuple[Any, str]:
    if "." not in path:
        return context.obj, path
    root, field = path.split(".", 1)
    if root == "real":
        raise RuntimeScriptError("real.* is read-only")
    owner = _scope_owner(root, context)
    if owner is None:
        raise RuntimeScriptError(f"Cannot resolve state owner {root!r}")
    return owner, field


def _array_descriptor(value: Any, name: str) -> dict[str, Any]:
    if not isinstance(value, dict) or value.get("__kind__") != "array":
        raise RuntimeScriptError(f"{name} is not an array")
    return value


def _array_key(indices: list[Any], dimensions: list[int], name: str) -> str:
    if len(indices) != len(dimensions):
        raise RuntimeScriptError(f"Array {name!r} requires {len(dimensions)} indices")
    normalized: list[str] = []
    for raw, limit in zip(indices, dimensions, strict=False):
        number = int(_number(raw))
        if number < 1 or number > int(limit):
            raise RuntimeScriptError(f"Array {name!r} index {number} is out of bounds")
        normalized.append(str(number))
    return ",".join(normalized)


def _array_get(descriptor: dict[str, Any], indices: list[Any], name: str) -> Any:
    key = _array_key(indices, list(descriptor["dimensions"]), name)
    return descriptor.get("values", {}).get(key, descriptor.get("default"))


def _array_set(descriptor: dict[str, Any], indices: list[Any], value: Any, name: str) -> None:
    key = _array_key(indices, list(descriptor["dimensions"]), name)
    descriptor.setdefault("values", {})[key] = value


def _clone_array_descriptor(descriptor: dict[str, Any]) -> dict[str, Any]:
    return {
        "__kind__": "array",
        "dimensions": list(descriptor.get("dimensions", [])),
        "default": descriptor.get("default"),
        "values": dict(descriptor.get("values", {})),
    }
