"""Standalone MuseLang3 command-line tool."""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

from .compiler import build_bundle
from .emitter import emit_batch
from .errors import MuseLang3Error
from .parser import parse_source_path
from .validator import validate_document


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="muselang", description="MuseLang3 scenario compiler")
    commands = parser.add_subparsers(dest="command", required=True)
    for name in ("lint", "test", "dev", "prod"):
        command = commands.add_parser(name)
        command.add_argument("source")
        command.add_argument("--out")
        command.add_argument("--batch-out")
        command.add_argument("--report")
    for name in ("runtime-install", "doctor"):
        command = commands.add_parser(name)
        command.add_argument("--game-root", default="muse-game")
        command.add_argument("--report")
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    try:
        if args.command in {"runtime-install", "doctor"}:
            from .installer import doctor_runtime, install_runtime
            result = (install_runtime if args.command == "runtime-install" else doctor_runtime)(args.game_root)
            result = {"command": args.command, **result}
        else:
            source = Path(args.source)
            document = parse_source_path(source)
            warnings = validate_document(document)
            bundle = build_bundle(document)
            result = {
                "mode": args.command, "language_version": "3.0", "source": str(source),
                "source_files": document.source_paths,
                "summary": {
                    "rooms": sum(noun.kind == "room" for noun in document.nouns),
                    "objects": sum(noun.kind == "object" for noun in document.nouns),
                    "characters": sum(noun.kind == "character" for noun in document.nouns),
                    "goals": len(document.goals),
                },
                "warnings": warnings, "status": "ok",
            }
            if args.command in {"dev", "prod"}:
                out = Path(args.out) if args.out else _default_path(source, ".muselang.json")
                out.write_text(json.dumps(bundle, indent=2), encoding="utf-8")
                result["bundle_path"] = str(out)
            if args.command == "prod" or args.batch_out:
                batch = Path(args.batch_out) if args.batch_out else _default_path(source, ".ev")
                batch.write_text(emit_batch(bundle), encoding="utf-8")
                result["batch_path"] = str(batch)
        if getattr(args, "report", None):
            Path(args.report).write_text(json.dumps(result, indent=2), encoding="utf-8")
        print(json.dumps(result, indent=2))
        return 0
    except (MuseLang3Error, FileNotFoundError) as exc:
        print(str(exc), file=sys.stderr)
        return 1


def _default_path(source: Path, suffix: str) -> Path:
    return (source / f"{source.name}{suffix}") if source.is_dir() else source.with_suffix(suffix)


if __name__ == "__main__":
    raise SystemExit(main())
