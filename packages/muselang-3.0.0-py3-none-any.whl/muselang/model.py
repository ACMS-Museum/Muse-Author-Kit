"""Source-aware MuseLang3 AST."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


Expr = dict[str, Any]
Template = list[dict[str, Any]]


@dataclass(frozen=True, slots=True)
class SourceSpan:
    path: str
    line: int
    column: int = 1

    @property
    def location(self) -> str:
        return f"{self.path}:{self.line}:{self.column}"


@dataclass(slots=True)
class ArgumentDef:
    name: str
    type_name: str
    optional: bool
    span: SourceSpan


@dataclass(slots=True)
class Statement:
    op: str
    span: SourceSpan
    data: dict[str, Any] = field(default_factory=dict)


@dataclass(slots=True)
class RoutineDef:
    name: str
    statements: list[Statement]
    span: SourceSpan


@dataclass(slots=True)
class VerbDef:
    name: str
    arguments: list[ArgumentDef]
    statements: list[Statement]
    span: SourceSpan
    aliases: list[str] = field(default_factory=list)


@dataclass(slots=True)
class NounDef:
    kind: str
    noun_id: str
    name: str | None
    location: str | None
    type_id: str | None
    span: SourceSpan
    aliases: list[str] = field(default_factory=list)
    description: str | None = None
    state: dict[str, Any] = field(default_factory=dict)
    arrays: dict[str, ArrayDecl] = field(default_factory=dict)
    verbs: list[VerbDef] = field(default_factory=list)
    routines: list[RoutineDef] = field(default_factory=list)


@dataclass(slots=True)
class GoalDef:
    goal_id: str
    description: str | None
    span: SourceSpan


@dataclass(slots=True)
class StateDefault:
    target: str
    value: Any
    span: SourceSpan


@dataclass(slots=True)
class ArrayDecl:
    target: str
    dimensions: list[int]
    initial: Any
    span: SourceSpan


@dataclass(slots=True)
class Document:
    path: str
    source_paths: list[str] = field(default_factory=list)
    nouns: list[NounDef] = field(default_factory=list)
    goals: list[GoalDef] = field(default_factory=list)
    state_defaults: list[StateDefault] = field(default_factory=list)
    array_defaults: list[ArrayDecl] = field(default_factory=list)
