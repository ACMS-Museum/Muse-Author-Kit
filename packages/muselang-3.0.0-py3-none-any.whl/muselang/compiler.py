"""Lower validated MuseLang3 source to canonical JSON metadata."""

from __future__ import annotations

from typing import Any

from .model import Document, Statement
from .validator import validate_document


SCENARIO_BEHAVIOUR = "behaviours.muselang.scenario_verbs.ScenarioVerbCmdSet"


def build_bundle(document: Document) -> dict[str, Any]:
    validate_document(document)
    return {
        "language_version": "3.0",
        "bundle_schema": 3,
        "runtime_api": 3,
        "source": document.path,
        "source_files": list(document.source_paths),
        "state_defaults": [
            _state_default(item.target, item.value) for item in document.state_defaults
        ] + [
            _state_default(item.target, _array_value(item.dimensions, item.initial)) for item in document.array_defaults
        ],
        "goals": [{"id": goal.goal_id, "description": goal.description} for goal in document.goals],
        "nouns": [_lower_noun(noun, document.state_defaults) for noun in document.nouns],
    }


def _state_default(target: str, value: Any) -> dict[str, Any]:
    return {"target": target.replace("game.", "scenario.", 1), "value": value}


def _lower_noun(noun, state_defaults) -> dict[str, Any]:
    routines = {routine.name: _lower_program(routine.statements) for routine in noun.routines}
    interactions = []
    for verb in noun.verbs:
        interactions.append({
            "id": verb.name,
            "verb": verb.name,
            "aliases": list(verb.aliases),
            "behaviour": SCENARIO_BEHAVIOUR,
            "arguments": [
                {"name": arg.name, "type": arg.type_name, "optional": arg.optional}
                for arg in verb.arguments
            ],
            "program": _lower_program(verb.statements),
            "routines": routines,
        })
    return {
        "kind": noun.kind,
        "id": noun.noun_id,
        "name": noun.name,
        "location": noun.location,
        "type_id": noun.type_id,
        "aliases": list(noun.aliases),
        "description": noun.description,
        "state": {
            **dict(noun.state),
            **{name: _array_value(array.dimensions, array.initial) for name, array in noun.arrays.items()},
        },
        "routines": routines,
        "state_defaults": [_state_default(item.target, item.value) for item in state_defaults],
        "interactions": interactions,
        "required_behaviours": [SCENARIO_BEHAVIOUR] if interactions else [],
    }


def _lower_program(statements: list[Statement]) -> list[dict[str, Any]]:
    program: list[dict[str, Any]] = []
    for statement in statements:
        step = {"op": statement.op, **statement.data}
        if statement.op == "if":
            step["branches"] = [
                {"condition": branch["condition"], "program": _lower_program(branch["program"])}
                for branch in statement.data["branches"]
            ]
            step["else"] = _lower_program(statement.data["else"])
        elif statement.op == "for":
            step["program"] = _lower_program(statement.data["program"])
        step["source"] = {"path": statement.span.path, "line": statement.span.line}
        program.append(step)
    return program


def _array_value(dimensions: list[int], initial: Any) -> dict[str, Any]:
    return {
        "__kind__": "array",
        "dimensions": list(dimensions),
        "default": initial,
        "values": {},
    }
