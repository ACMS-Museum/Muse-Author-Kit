"""Indentation-sensitive MuseLang3 parser."""

from __future__ import annotations

import ast
import re
import shlex
from dataclasses import dataclass
from pathlib import Path

from .errors import ParseError
from .expressions import parse_expression, parse_template
from .model import ArgumentDef, ArrayDecl, Document, GoalDef, NounDef, RoutineDef, SourceSpan, StateDefault, Statement, VerbDef


_IDENT = r"[A-Za-z_][\w-]*"
_ARGUMENT = re.compile(rf"<(?P<name>{_IDENT})(?::(?P<type>{_IDENT}))?(?P<optional>\?)?>")


@dataclass(frozen=True, slots=True)
class _Line:
    indent: int
    text: str
    span: SourceSpan


class Parser:
    def __init__(self, path: str | Path, text: str):
        self.path = str(path)
        self.lines = _source_lines(self.path, text)
        self.index = 0

    def parse(self) -> Document:
        document = Document(path=self.path, source_paths=[self.path])
        while self.index < len(self.lines):
            line = self.lines[self.index]
            if line.indent:
                self._fail(line, "top-level declaration must not be indented")
            keyword = line.text.split(None, 1)[0]
            if keyword == "room":
                document.nouns.append(self._parse_noun("room"))
            elif keyword in {"object", "obj"}:
                document.nouns.append(self._parse_noun("object"))
            elif keyword in {"character", "char"}:
                document.nouns.append(self._parse_noun("character"))
            elif keyword == "goal":
                document.goals.append(self._parse_goal())
            elif keyword == "state":
                document.state_defaults.append(self._parse_state_default())
            elif keyword == "array":
                document.array_defaults.append(self._parse_array_default())
            else:
                self._fail(line, f"unknown top-level declaration {keyword!r}")
        return document

    def _parse_noun(self, kind: str) -> NounDef:
        line = self.lines[self.index]
        words = _split(line)
        if len(words) < 2:
            self._fail(line, f"{kind} id is required")
        noun_id = words[1]
        location = None
        type_id = None
        name = None
        cursor = 2
        while cursor < len(words):
            word = words[cursor]
            if word == "in" and cursor + 1 < len(words):
                location = words[cursor + 1]
                cursor += 2
            elif word == "from" and cursor + 1 < len(words):
                type_id = words[cursor + 1]
                cursor += 2
            elif name is None:
                name = word
                cursor += 1
            else:
                self._fail(line, f"unexpected {kind} header value {word!r}")
        if kind in {"object", "character"} and location is None:
            self._fail(line, f"{kind} {noun_id!r} requires 'in <room>'")
        noun = NounDef(kind, noun_id, name, location, type_id, line.span)
        self.index += 1
        if self.index >= len(self.lines) or self.lines[self.index].indent <= line.indent:
            return noun
        body_indent = self.lines[self.index].indent
        while self.index < len(self.lines) and self.lines[self.index].indent == body_indent:
            child = self.lines[self.index]
            if child.text.startswith("alias "):
                noun.aliases.extend(_split(child)[1:])
                self.index += 1
            elif child.text.startswith("desc ") or child.text.startswith("description "):
                noun.description = _quoted_value(child, child.text.split(None, 1)[1])
                self.index += 1
            elif child.text.startswith("state "):
                target, value = self._parse_assignment_text(child, child.text[6:], declaration=True)
                if "." in target:
                    self._fail(child, "object state declarations use an unqualified name")
                noun.state[target] = value
                self.index += 1
            elif child.text.startswith("array "):
                array_decl = self._parse_array_declaration(child, child.text[6:], top_level=False)
                if "." in array_decl.target:
                    self._fail(child, "object array declarations use an unqualified name")
                noun.arrays[array_decl.target] = array_decl
                self.index += 1
            elif child.text.startswith("routine "):
                noun.routines.append(self._parse_routine())
            elif child.text.startswith("verb "):
                noun.verbs.append(self._parse_verb())
            else:
                self._fail(child, f"invalid {kind} child statement {child.text!r}")
        if self.index < len(self.lines) and self.lines[self.index].indent > line.indent:
            self._fail(self.lines[self.index], "inconsistent child indentation")
        return noun

    def _parse_goal(self) -> GoalDef:
        line = self.lines[self.index]
        words = _split(line)
        if len(words) != 2:
            self._fail(line, "goal syntax is 'goal <id>'")
        self.index += 1
        description = None
        if self.index < len(self.lines) and self.lines[self.index].indent > line.indent:
            child = self.lines[self.index]
            if not child.text.startswith("desc "):
                self._fail(child, "a goal may only contain a description")
            description = _quoted_value(child, child.text.split(None, 1)[1])
            self.index += 1
        return GoalDef(words[1], description, line.span)

    def _parse_state_default(self) -> StateDefault:
        line = self.lines[self.index]
        target, value = self._parse_assignment_text(line, line.text[6:], declaration=True)
        if "." not in target:
            self._fail(line, "top-level state requires a namespace, such as 'player.score'")
        self.index += 1
        return StateDefault(target, value, line.span)

    def _parse_array_default(self) -> ArrayDecl:
        line = self.lines[self.index]
        result = self._parse_array_declaration(line, line.text[6:], top_level=True)
        if "." not in result.target:
            self._fail(line, "top-level array requires a namespace, such as 'player.board[8,8]'")
        self.index += 1
        return result

    def _parse_routine(self) -> RoutineDef:
        line = self.lines[self.index]
        words = _split(line)
        if len(words) != 2:
            self._fail(line, "routine syntax is 'routine <id>'")
        self.index += 1
        return RoutineDef(words[1], self._required_statements(line), line.span)

    def _parse_verb(self) -> VerbDef:
        line = self.lines[self.index]
        header = line.text[5:].strip()
        match = re.match(rf"^(?P<name>{_IDENT})(?P<args>.*)$", header)
        if not match:
            self._fail(line, "verb name is required")
        name = match.group("name")
        argument_text = match.group("args").strip()
        arguments: list[ArgumentDef] = []
        position = 0
        for arg_match in _ARGUMENT.finditer(argument_text):
            if argument_text[position:arg_match.start()].strip():
                self._fail(line, "only simple positional verb arguments are supported")
            arguments.append(ArgumentDef(
                arg_match.group("name"), arg_match.group("type") or "word",
                bool(arg_match.group("optional")), line.span,
            ))
            position = arg_match.end()
        if argument_text[position:].strip():
            self._fail(line, "invalid verb argument declaration")
        self.index += 1
        statements = self._required_statements(line)
        return VerbDef(name, arguments, statements, line.span)

    def _required_statements(self, header: _Line) -> list[Statement]:
        if self.index >= len(self.lines) or self.lines[self.index].indent <= header.indent:
            self._fail(header, "an indented statement block is required")
        return self._parse_statements(self.lines[self.index].indent)

    def _parse_statements(self, indent: int) -> list[Statement]:
        statements: list[Statement] = []
        while self.index < len(self.lines) and self.lines[self.index].indent == indent:
            line = self.lines[self.index]
            text = line.text
            if text.startswith("if "):
                statements.append(self._parse_if(indent))
                continue
            if text.startswith("for "):
                statements.append(self._parse_for())
                continue
            if text.startswith(("elif ", "else")):
                break
            if text.startswith("let "):
                match = re.match(rf"let\s+({_IDENT})\s*=\s*(.+)$", text)
                if not match:
                    self._fail(line, "let syntax is 'let <name> = <expression>'")
                statements.append(Statement("let", line.span, {"name": match.group(1), "value": parse_expression(match.group(2), line.span)}))
            elif text.startswith("set "):
                match = re.match(r"set\s+(.+?)\s*(=|\+=|-=)\s*(.+)$", text)
                if not match:
                    self._fail(line, "set syntax is 'set <target> <op> <expression>'")
                statements.append(Statement("set", line.span, {
                    "target": self._parse_set_target(line, match.group(1)), "assignment": match.group(2),
                    "value": parse_expression(match.group(3), line.span),
                }))
            elif text.startswith("say ") or text.startswith("hint "):
                op, source = text.split(None, 1)
                value = _quoted_value(line, source)
                statements.append(Statement(op, line.span, {"template": parse_template(value, line.span)}))
            elif text.startswith("run "):
                target = text[4:].strip()
                if not re.fullmatch(rf"{_IDENT}(?:\.{_IDENT})?", target):
                    self._fail(line, "invalid routine reference")
                statements.append(Statement("run", line.span, {"target": target}))
            elif text.startswith("achieve "):
                statements.append(Statement("achieve", line.span, {"goal": text[8:].strip()}))
            elif text.startswith("move "):
                match = re.match(rf"move\s+({_IDENT})\s+to\s+({_IDENT})$", text)
                if not match:
                    self._fail(line, "move syntax is 'move <object> to <location>'")
                statements.append(Statement("move", line.span, {"object": match.group(1), "location": match.group(2)}))
            elif text.startswith("call "):
                statements.append(Statement("call", line.span, {"target": text[5:].strip()}))
            elif text in {"stop", "end"}:
                statements.append(Statement(text, line.span))
            else:
                self._fail(line, f"unknown statement {text!r}")
            self.index += 1
            if self.index < len(self.lines) and self.lines[self.index].indent > indent:
                self._fail(self.lines[self.index], "unexpected indented block")
        return statements

    def _parse_if(self, indent: int) -> Statement:
        start = self.lines[self.index]
        branches: list[dict[str, object]] = []
        else_program: list[Statement] = []
        while self.index < len(self.lines) and self.lines[self.index].indent == indent:
            line = self.lines[self.index]
            if line.text.startswith("if ") or line.text.startswith("elif "):
                source = line.text.split(None, 1)[1]
                self.index += 1
                branches.append({"condition": parse_expression(source, line.span), "program": self._required_statements(line)})
                continue
            if line.text == "else":
                self.index += 1
                else_program = self._required_statements(line)
            break
        return Statement("if", start.span, {"branches": branches, "else": else_program})

    def _parse_for(self) -> Statement:
        line = self.lines[self.index]
        match = re.match(rf"for\s+({_IDENT})\s*=\s*(.+?)\s+to\s+(.+?)(?:\s+step\s+(.+))?$", line.text)
        if not match:
            self._fail(line, "for syntax is 'for <name> = <start> to <end> [step <increment>]'")
        self.index += 1
        return Statement("for", line.span, {
            "name": match.group(1),
            "start": parse_expression(match.group(2), line.span),
            "end": parse_expression(match.group(3), line.span),
            "step": parse_expression(match.group(4), line.span) if match.group(4) else {"kind": "literal", "value": 1},
            "program": self._required_statements(line),
        })

    def _parse_assignment_text(self, line: _Line, source: str, declaration: bool) -> tuple[str, object]:
        match = re.match(rf"({_IDENT}(?:\.{_IDENT})*)\s*=\s*(.+)$", source)
        if not match:
            self._fail(line, "state syntax is 'state <name> = <literal>'")
        expr = parse_expression(match.group(2), line.span)
        if declaration and expr.get("kind") != "literal":
            self._fail(line, "state initial values must be literals")
        return match.group(1), expr.get("value")

    def _parse_array_declaration(self, line: _Line, source: str, top_level: bool) -> ArrayDecl:
        match = re.match(rf"(?P<target>{_IDENT}(?:\.{_IDENT})*)\[(?P<dims>[^\]]+)\](?:\s*=\s*(?P<value>.+))?$", source)
        if not match:
            self._fail(line, "array syntax is 'array <name>[size] = <literal>'")
        dimensions = [self._parse_dimension(line, item.strip()) for item in match.group("dims").split(",")]
        if any(value <= 0 for value in dimensions):
            self._fail(line, "array dimensions must be positive integers")
        value_text = match.group("value")
        if value_text is None:
            initial = None
        else:
            expr = parse_expression(value_text, line.span)
            if expr.get("kind") != "literal":
                self._fail(line, "array initial values must be literals")
            initial = expr.get("value")
        return ArrayDecl(match.group("target"), dimensions, initial, line.span)

    def _parse_dimension(self, line: _Line, source: str) -> int:
        expr = parse_expression(source, line.span)
        if expr.get("kind") != "literal" or not isinstance(expr.get("value"), int) or isinstance(expr.get("value"), bool):
            self._fail(line, "array dimensions must be integer literals")
        return int(expr["value"])

    def _parse_set_target(self, line: _Line, source: str) -> dict[str, object]:
        target = parse_expression(source, line.span)
        if target.get("kind") not in {"reference", "array"}:
            self._fail(line, "set target must be a variable or array element")
        return target

    def _fail(self, line: _Line, message: str):
        raise ParseError(f"{line.span.location}: {message}")


def _source_lines(path: str, text: str) -> list[_Line]:
    result: list[_Line] = []
    for number, raw in enumerate(text.splitlines(), start=1):
        leading = raw[:len(raw) - len(raw.lstrip(" \t"))]
        if "\t" in leading:
            raise ParseError(f"{path}:{number}:1: tabs are not allowed in indentation")
        content = _strip_comment(raw[len(leading):]).rstrip()
        if content.strip():
            result.append(_Line(len(leading), content.strip(), SourceSpan(path, number, len(leading) + 1)))
    return result


def _strip_comment(text: str) -> str:
    quoted = False
    escaped = False
    for index, char in enumerate(text):
        if escaped:
            escaped = False
        elif char == "\\" and quoted:
            escaped = True
        elif char == '"':
            quoted = not quoted
        elif char == "#" and not quoted:
            return text[:index]
    return text


def _split(line: _Line) -> list[str]:
    try:
        return shlex.split(line.text, posix=True)
    except ValueError as exc:
        raise ParseError(f"{line.span.location}: {exc}") from None


def _quoted_value(line: _Line, source: str) -> str:
    try:
        value = ast.literal_eval(source)
    except (SyntaxError, ValueError):
        raise ParseError(f"{line.span.location}: expected a quoted string") from None
    if not isinstance(value, str):
        raise ParseError(f"{line.span.location}: expected a quoted string")
    return value


def parse_text(text: str, path: str | Path = "<memory>") -> Document:
    return Parser(path, text).parse()


def parse_file(path: str | Path) -> Document:
    source = Path(path)
    return parse_text(source.read_text(encoding="utf-8"), source)


def parse_source_path(path: str | Path) -> Document:
    source = Path(path)
    if source.is_file():
        return parse_file(source)
    if not source.is_dir():
        raise FileNotFoundError(f"MuseLang3 source path not found: {source}")
    files = sorted(item for item in source.rglob("*.muse") if item.is_file())
    if not files:
        raise FileNotFoundError(f"No .muse files found under {source}")
    combined = Document(path=str(source), source_paths=[])
    for item in files:
        document = parse_file(item)
        combined.source_paths.extend(document.source_paths)
        combined.nouns.extend(document.nouns)
        combined.goals.extend(document.goals)
        combined.state_defaults.extend(document.state_defaults)
        combined.array_defaults.extend(document.array_defaults)
    return combined
