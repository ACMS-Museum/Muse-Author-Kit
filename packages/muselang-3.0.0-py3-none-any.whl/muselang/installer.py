"""Install and verify the standalone MuseLang3 Evennia runtime."""

from __future__ import annotations

from importlib import resources
from pathlib import Path


ROOT_MODULES = ("errors.py", "runtime.py")
TEMPLATE_MODULES = ("__init__.py", "runtime_version.py", "scenario_verbs.py")


def runtime_target_dir(game_root: str | Path) -> Path:
    return Path(game_root) / "behaviours" / "muselang"


def install_runtime(game_root: str | Path) -> dict[str, object]:
    target = runtime_target_dir(game_root)
    target.mkdir(parents=True, exist_ok=True)
    installed: list[str] = []
    updated: list[str] = []
    unchanged: list[str] = []
    for name in (*ROOT_MODULES, *TEMPLATE_MODULES):
        expected = _module_text(name)
        path = target / name
        if not path.exists():
            path.write_text(expected, encoding="utf-8")
            installed.append(name)
        elif path.read_text(encoding="utf-8") != expected:
            path.write_text(expected, encoding="utf-8")
            updated.append(name)
        else:
            unchanged.append(name)
    return {
        "language_version": "3.0", "runtime_api": 3,
        "game_root": str(Path(game_root)), "target_dir": str(target),
        "installed": installed, "updated": updated, "unchanged": unchanged,
    }


def doctor_runtime(game_root: str | Path) -> dict[str, object]:
    target = runtime_target_dir(game_root)
    checks = []
    healthy = True
    for name in (*ROOT_MODULES, *TEMPLATE_MODULES):
        path = target / name
        if not path.exists():
            status = "missing"
        elif path.read_text(encoding="utf-8") != _module_text(name):
            status = "out_of_date"
        else:
            status = "ok"
        healthy &= status == "ok"
        checks.append({"module": name, "status": status})
    return {
        "language_version": "3.0", "runtime_api": 3,
        "game_root": str(Path(game_root)), "target_dir": str(target),
        "healthy": healthy, "checks": checks,
    }


def _module_text(name: str) -> str:
    package = resources.files("muselang")
    if name in ROOT_MODULES:
        return package.joinpath(name).read_text(encoding="utf-8")
    return package.joinpath("runtime_templates", name).read_text(encoding="utf-8")
