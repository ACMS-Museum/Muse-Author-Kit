"""Token-based MuseLang 1.0 parser."""

from __future__ import annotations

from pathlib import Path

from .condition_parser import ConditionParser
from .lexer import lex_source
from .model import (
    CallStmt,
    DialogueNode,
    EndStmt,
    ExitDef,
    GiveStmt,
    GotoStmt,
    HideStmt,
    HintStmt,
    IfBranch,
    IfStmt,
    MoveStmt,
    MuseDocument,
    NounDef,
    OptionStmt,
    RuleDef,
    SayStmt,
    SetStmt,
    ShowStmt,
    SourceSpan,
    Statement,
    TextBlock,
    TextBranch,
    UntilStmt,
    VerbDef,
    WhileStmt,
)
from .token_stream import TokenStream
from .tokens import Token, TokenKind


class MuseParser:
    """Parse the stable MuseLang 1.0 grammar."""

    def __init__(self, path: Path, text: str):
        self.path = str(path)
        self.stream = TokenStream(lex_source(path, text))

    def parse(self) -> MuseDocument:
        document = MuseDocument(path=self.path, source_paths=[self.path])
        while not self.stream.at(TokenKind.EOF):
            if self.stream.match(TokenKind.NEWLINE):
                continue
            if self.stream.at(TokenKind.INDENT):
                raise self.stream.error("top-level declaration must not be indented")
            if self.stream.at_keyword("room"):
                document.rooms.append(self._parse_room())
            elif self.stream.at_keyword("obj") or self.stream.at_keyword("object"):
                document.objects.append(self._parse_object())
            elif self.stream.at_keyword("char") or self.stream.at_keyword("character"):
                document.characters.append(self._parse_character())
            elif self.stream.at_keyword("rule"):
                document.rules.append(self._parse_rule())
            else:
                raise self.stream.error(f"unknown top-level declaration {self.stream.peek().lexeme!r}")
        return document

    def _parse_room(self) -> NounDef:
        start = self.stream.expect_keyword("room")
        noun_id = self.stream.expect_identifier("room id").lexeme
        name = self._optional_string()
        self._end_header()
        noun = NounDef(kind="room", noun_id=noun_id, name=name, location=None, span=start.span)
        self._parse_noun_body(noun)
        return noun

    def _parse_object(self) -> NounDef:
        start = self.stream.expect_identifier("'obj' or 'object'")
        if start.lexeme not in {"obj", "object"}:
            raise self.stream.error("expected 'obj' or 'object'", start)
        noun_id = self.stream.expect_identifier("object id").lexeme
        self.stream.expect_keyword("in")
        location = self.stream.expect_identifier("room id").lexeme
        name = self._optional_string()
        self._end_header()
        noun = NounDef(kind="object", noun_id=noun_id, name=name, location=location, span=start.span)
        self._parse_noun_body(noun)
        return noun

    def _parse_character(self) -> NounDef:
        start = self.stream.expect_identifier("'char' or 'character'")
        if start.lexeme not in {"char", "character"}:
            raise self.stream.error("expected 'char' or 'character'", start)
        noun_id = self.stream.expect_identifier("character id").lexeme
        self.stream.expect_keyword("in")
        location = self.stream.expect_identifier("room id").lexeme
        name = self._optional_string()
        self._end_header()
        noun = NounDef(kind="character", noun_id=noun_id, name=name, location=location, span=start.span)
        self._parse_noun_body(noun)
        return noun

    def _parse_rule(self) -> RuleDef:
        start = self.stream.expect_keyword("rule")
        header_tokens = self._take_until(TokenKind.NEWLINE)
        if not header_tokens:
            raise self.stream.error("rule header is required", start)
        self.stream.expect(TokenKind.NEWLINE, "end of line")
        statements = self._parse_statement_block()
        return RuleDef(header=self._tokens_as_text(header_tokens), statements=statements, span=start.span)

    def _parse_noun_body(self, noun: NounDef) -> None:
        if not self.stream.match(TokenKind.INDENT):
            return
        while not self.stream.at(TokenKind.DEDENT):
            if self.stream.at(TokenKind.EOF):
                raise self.stream.error("unterminated noun block")
            if self.stream.match(TokenKind.NEWLINE):
                continue
            if self.stream.at_keyword("alias"):
                self.stream.take()
                noun.aliases.extend(self._alias_values())
            elif self.stream.at_keyword("desc") or self.stream.at_keyword("description"):
                self.stream.take()
                noun.description = self._parse_text_block("description")
            elif self.stream.at_keyword("tag"):
                self.stream.take()
                noun.tags.append(self.stream.expect_identifier("tag").lexeme)
                self._end_line()
            elif self.stream.at_keyword("state"):
                self.stream.take()
                name = self.stream.expect_identifier("state name").lexeme
                self.stream.expect(TokenKind.EQUAL, "'='")
                noun.state[name] = self._parse_literal()
                self._end_line()
            elif self.stream.at_keyword("portable"):
                token = self.stream.take()
                value = self.stream.expect_identifier("'true' or 'false'")
                if value.lexeme not in {"true", "false"}:
                    raise self.stream.error("portable must be true or false", value)
                noun.portable = value.lexeme == "true"
                self._end_line()
            elif self.stream.at_keyword("type"):
                self.stream.take()
                noun.type_id = self.stream.expect_identifier("type id").lexeme
                self._end_line()
            elif noun.kind == "room" and self.stream.at_keyword("exit"):
                noun.exits.append(self._parse_exit(noun.noun_id))
            elif self.stream.at_keyword("verb"):
                noun.verbs.append(self._parse_verb())
            elif self.stream.at_keyword("dialogue"):
                if noun.dialogue_entry is not None:
                    raise self.stream.error("duplicate dialogue entry")
                noun.dialogue_entry, node = self._parse_dialogue_entry()
                noun.dialogue_nodes.append(node)
            elif self.stream.at_keyword("node"):
                noun.dialogue_nodes.append(self._parse_dialogue_node())
            else:
                raise self.stream.error(f"invalid noun child statement {self.stream.peek().lexeme!r}")
        self.stream.take()

    def _parse_exit(self, source_room_id: str) -> ExitDef:
        start = self.stream.expect_keyword("exit")
        exit_name = self.stream.expect_identifier("exit name").lexeme
        self.stream.expect_keyword("to")
        destination = self.stream.expect_identifier("destination room").lexeme
        self._end_line()
        exit_def = ExitDef(
            source_room_id=source_room_id,
            exit_name=exit_name,
            destination_room_id=destination,
            span=start.span,
        )
        if not self.stream.match(TokenKind.INDENT):
            return exit_def
        while not self.stream.at(TokenKind.DEDENT):
            if self.stream.match(TokenKind.NEWLINE):
                continue
            if self.stream.match_keyword("alias"):
                exit_def.aliases.extend(self._alias_values())
            elif self.stream.match_keyword("desc") or self.stream.match_keyword("description"):
                exit_def.description = self._parse_text_block("description")
            elif self.stream.match_keyword("tag"):
                exit_def.tags.append(self._text_value("tag"))
            elif self.stream.match_keyword("state"):
                name = self.stream.expect_identifier("state name").lexeme
                self.stream.expect(TokenKind.EQUAL, "'='")
                exit_def.state[name] = self._parse_literal()
                self._end_line()
            else:
                raise self.stream.error(f"invalid exit child statement {self.stream.peek().lexeme!r}")
        self.stream.take()
        return exit_def

    def _parse_verb(self) -> VerbDef:
        start = self.stream.expect_keyword("verb")
        name = self.stream.expect_identifier("verb name").lexeme
        aliases: list[str] = []
        while self.stream.match_keyword("alias"):
            aliases.append(self.stream.expect_identifier("verb alias").lexeme)
        statements: list[Statement]
        if self.stream.at_keyword("say"):
            say = self.stream.take()
            text = self._required_string("inline verb message")
            self._end_line()
            statements = [SayStmt(kind="say", span=say.span, text=text)]
        else:
            self._end_line()
            aliases, statements = self._parse_verb_body(aliases)
        return VerbDef(name=name, aliases=aliases, statements=statements, span=start.span)

    def _parse_verb_body(self, aliases: list[str]) -> tuple[list[str], list[Statement]]:
        if not self.stream.match(TokenKind.INDENT):
            return aliases, []
        statements: list[Statement] = []
        while not self.stream.at(TokenKind.DEDENT):
            if self.stream.at(TokenKind.EOF):
                raise self.stream.error("unterminated verb block")
            if self.stream.match(TokenKind.NEWLINE):
                continue
            if self.stream.match_keyword("alias"):
                aliases.extend(self._alias_values())
                continue
            statements.append(self._parse_statement())
        self.stream.take()
        return aliases, statements

    def _parse_dialogue_entry(self) -> tuple[str, DialogueNode]:
        start = self.stream.expect_keyword("dialogue")
        node_id = self.stream.expect_identifier("dialogue entry node").lexeme
        self._end_line()
        node = DialogueNode(node_id=node_id, statements=self._parse_statement_block(), span=start.span)
        return node_id, node

    def _parse_dialogue_node(self) -> DialogueNode:
        start = self.stream.expect_keyword("node")
        node_id = self.stream.expect_identifier("dialogue node id").lexeme
        self._end_line()
        return DialogueNode(node_id=node_id, statements=self._parse_statement_block(), span=start.span)

    def _parse_statement_block(self) -> list[Statement]:
        if not self.stream.match(TokenKind.INDENT):
            return []
        statements: list[Statement] = []
        while not self.stream.at(TokenKind.DEDENT):
            if self.stream.at(TokenKind.EOF):
                raise self.stream.error("unterminated statement block")
            if self.stream.match(TokenKind.NEWLINE):
                continue
            statements.append(self._parse_statement())
        self.stream.take()
        return statements

    def _parse_statement(self) -> Statement:
        if self.stream.at_keyword("if"):
            return self._parse_if()
        start = self.stream.expect_identifier("statement")
        keyword = start.lexeme
        if keyword in {"say", "hint"}:
            text = self._parse_text_value(keyword)
            cls = SayStmt if keyword == "say" else HintStmt
            return cls(kind=keyword, span=start.span, text=text)
        if keyword == "set":
            target = self._parse_reference()
            self.stream.expect(TokenKind.EQUAL, "'='")
            value = self._parse_literal()
            self._end_line()
            return SetStmt(kind="set", span=start.span, target=target, value=value)
        if keyword in {"goto", "call", "show", "hide"}:
            target = self._parse_reference()
            self._end_line()
            classes = {"goto": GotoStmt, "call": CallStmt, "show": ShowStmt, "hide": HideStmt}
            return classes[keyword](kind=keyword, span=start.span, target=target)
        if keyword == "end":
            self._end_line()
            return EndStmt(kind="end", span=start.span)
        if keyword in {"while", "until"}:
            condition = ConditionParser(self.stream).parse()
            self._end_line()
            statements = self._parse_statement_block()
            cls = WhileStmt if keyword == "while" else UntilStmt
            return cls(kind=keyword, span=start.span, condition=condition, statements=statements)
        if keyword == "move":
            object_id = self.stream.expect_identifier("object id").lexeme
            self.stream.expect_keyword("to")
            location_id = self.stream.expect_identifier("location id").lexeme
            self._end_line()
            return MoveStmt(kind="move", span=start.span, object_id=object_id, location_id=location_id)
        if keyword == "give":
            object_id = self.stream.expect_identifier("object id").lexeme
            self.stream.expect_keyword("to")
            character_id = self.stream.expect_identifier("character id").lexeme
            self._end_line()
            return GiveStmt(kind="give", span=start.span, object_id=object_id, character_id=character_id)
        if keyword == "option":
            return self._parse_option(start.span)
        raise self.stream.error(f"unknown statement {keyword!r}", start)

    def _parse_if(self) -> IfStmt:
        start = self.stream.expect_keyword("if")
        branches = [self._parse_if_branch(start)]
        while self.stream.at_keyword("elif"):
            branch = self.stream.take()
            branches.append(self._parse_if_branch(branch))
        else_statements: list[Statement] = []
        if self.stream.match_keyword("else"):
            self._end_line()
            else_statements = self._parse_statement_block()
        return IfStmt(kind="if", span=start.span, branches=branches, else_statements=else_statements)

    def _parse_if_branch(self, start: Token) -> IfBranch:
        condition = ConditionParser(self.stream).parse()
        self._end_line()
        statements = self._parse_statement_block()
        return IfBranch(condition=condition, statements=statements, span=start.span)

    def _parse_option(self, span: SourceSpan) -> OptionStmt:
        option_id = self.stream.expect_identifier("option id").lexeme
        label_token = self.stream.expect(TokenKind.STRING, "option label")
        label, hotkey = self._extract_hotkey(str(label_token.value), label_token)
        condition = None
        if self.stream.match_keyword("if"):
            condition = ConditionParser(self.stream, {TokenKind.ARROW}).parse()
        self.stream.expect(TokenKind.ARROW, "'->'")
        target = self.stream.expect_identifier("dialogue target node").lexeme
        self._end_line()
        return OptionStmt(
            kind="option",
            span=span,
            option_id=option_id,
            label=label,
            hotkey=hotkey,
            target=target,
            condition=condition,
        )

    def _optional_string(self) -> str | None:
        token = self.stream.match(TokenKind.STRING)
        return str(token.value) if token else None

    def _required_string(self, description: str) -> str:
        token = self.stream.expect(TokenKind.STRING, description)
        return str(token.value)

    def _parse_text_value(self, keyword: str) -> str:
        if self.stream.at(TokenKind.STRING):
            value = self._required_string(f"{keyword} text")
            self._end_line()
            return value
        self._end_line()
        self.stream.expect(TokenKind.INDENT, f"indented {keyword} text")
        lines: list[str] = []
        while not self.stream.at(TokenKind.DEDENT):
            if self.stream.match(TokenKind.NEWLINE):
                continue
            lines.append(self._required_string(f"{keyword} text line"))
            self._end_line()
        self.stream.take()
        if not lines:
            raise self.stream.error(f"{keyword} text is required")
        return "\n".join(lines)

    def _parse_text_block(self, description: str) -> TextBlock:
        if self.stream.at(TokenKind.STRING):
            token = self.stream.take()
            self._end_line()
            return TextBlock(branches=[TextBranch(condition=None, lines=[str(token.value)], span=token.span)])

        self._end_line()
        self.stream.expect(TokenKind.INDENT, f"indented {description}")
        if self.stream.at_keyword("if"):
            branches = self._parse_conditional_text_branches()
        else:
            first = self.stream.peek()
            branches = [TextBranch(condition=None, lines=self._parse_text_lines(), span=first.span)]
        self.stream.expect(TokenKind.DEDENT, f"end of {description}")
        return TextBlock(branches=branches)

    def _parse_conditional_text_branches(self) -> list[TextBranch]:
        branches: list[TextBranch] = []
        while self.stream.at_keyword("if") or self.stream.at_keyword("elif"):
            start = self.stream.take()
            condition = ConditionParser(self.stream).parse()
            self._end_line()
            self.stream.expect(TokenKind.INDENT, "indented conditional description")
            lines = self._parse_text_lines()
            self.stream.expect(TokenKind.DEDENT, "end of conditional description branch")
            branches.append(TextBranch(condition=condition, lines=lines, span=start.span))
        if self.stream.match_keyword("else"):
            start = self.stream.peek(-1)
            self._end_line()
            self.stream.expect(TokenKind.INDENT, "indented else description")
            lines = self._parse_text_lines()
            self.stream.expect(TokenKind.DEDENT, "end of else description branch")
            branches.append(TextBranch(condition=None, lines=lines, span=start.span))
        return branches

    def _parse_text_lines(self) -> list[str]:
        lines: list[str] = []
        while not self.stream.at(TokenKind.DEDENT):
            if self.stream.match(TokenKind.NEWLINE):
                continue
            lines.append(self._required_string("quoted text line"))
            self._end_line()
        if not lines:
            raise self.stream.error("text block must contain at least one quoted line")
        return lines

    def _alias_values(self) -> list[str]:
        aliases: list[str] = []
        while not self.stream.at(TokenKind.NEWLINE):
            token = self.stream.peek()
            if token.kind not in {TokenKind.IDENT, TokenKind.STRING}:
                raise self.stream.error("alias must be an identifier or string", token)
            aliases.append(str(self.stream.take().value))
        self._end_line()
        if not aliases:
            raise self.stream.error("at least one alias is required")
        return aliases

    def _text_value(self, description: str) -> str:
        if self.stream.at(TokenKind.STRING):
            value = str(self.stream.take().value)
            self._end_line()
            return value
        tokens = self._take_until(TokenKind.NEWLINE)
        if not tokens:
            raise self.stream.error(f"{description} value is required")
        self.stream.expect(TokenKind.NEWLINE, "end of line")
        return self._tokens_as_text(tokens)

    def _parse_reference(self) -> str:
        parts = [self.stream.expect_identifier("reference").lexeme]
        while self.stream.match(TokenKind.DOT):
            parts.append(self.stream.expect_identifier("identifier after '.'").lexeme)
        return ".".join(parts)

    def _parse_literal(self) -> str | bool | int | float:
        token = self.stream.peek()
        if token.kind is TokenKind.STRING:
            return str(self.stream.take().value)
        if token.kind is TokenKind.INTEGER:
            return int(self.stream.take().value)
        if token.kind is TokenKind.FLOAT:
            return float(self.stream.take().value)
        if token.kind is TokenKind.IDENT:
            value = self._parse_reference()
            if value == "true":
                return True
            if value == "false":
                return False
            return value
        raise self.stream.error("expected literal value")

    def _end_header(self) -> None:
        self._end_line()

    def _end_line(self) -> None:
        self.stream.expect(TokenKind.NEWLINE, "end of line")

    def _take_until(self, kind: TokenKind) -> list[Token]:
        tokens: list[Token] = []
        while not self.stream.at(kind) and not self.stream.at(TokenKind.EOF):
            tokens.append(self.stream.take())
        return tokens

    @staticmethod
    def _tokens_as_text(tokens: list[Token]) -> str:
        text = ""
        for token in tokens:
            if token.kind is TokenKind.DOT:
                text += "."
            elif not text or text.endswith("."):
                text += token.lexeme
            else:
                text += " " + token.lexeme
        return text

    def _extract_hotkey(self, label: str, token: Token) -> tuple[str, str | None]:
        markers: list[tuple[int, str]] = []
        index = 0
        while index < len(label):
            if label[index] == "<":
                close = label.find(">", index + 1)
                if close == -1:
                    raise self.stream.error("unterminated option hotkey marker", token)
                markers.append((index, label[index + 1 : close]))
                index = close + 1
            else:
                index += 1
        if not markers:
            return label, None
        if len(markers) > 1 or len(markers[0][1]) != 1:
            raise self.stream.error("option label must contain exactly one character in at most one hotkey marker", token)
        marker_index, hotkey = markers[0]
        cleaned = label[:marker_index] + hotkey + label[marker_index + 3 :]
        return cleaned, hotkey


def parse_text(text: str, path: str | Path = "<memory>") -> MuseDocument:
    """Parse MuseLang text into a source-aware document."""

    return MuseParser(Path(path), text).parse()


def parse_file(path: str | Path) -> MuseDocument:
    """Parse a MuseLang source file into a document."""

    source_path = Path(path)
    return MuseParser(source_path, source_path.read_text(encoding="utf-8")).parse()


def parse_source_path(path: str | Path) -> MuseDocument:
    """Parse a MuseLang source file or a folder of source files."""

    source_path = Path(path)
    if source_path.is_file():
        return parse_file(source_path)

    source_files = _discover_source_files(source_path)
    document = MuseDocument(path=str(source_path), source_paths=[str(item) for item in source_files])
    for item in source_files:
        parsed = parse_file(item)
        document.rooms.extend(parsed.rooms)
        document.objects.extend(parsed.objects)
        document.characters.extend(parsed.characters)
        document.rules.extend(parsed.rules)
    return document


def _discover_source_files(source_path: Path) -> list[Path]:
    if not source_path.exists():
        raise FileNotFoundError(f"No such file or directory: {source_path}")
    if not source_path.is_dir():
        raise FileNotFoundError(f"Not a MuseLang source file or folder: {source_path}")

    patterns = ("*.muse", "*.muselang")
    files: list[Path] = []
    for pattern in patterns:
        files.extend(source_path.glob(pattern))
    files = sorted({item.resolve(): item for item in files}.values(), key=lambda item: item.name.casefold())
    if not files:
        raise FileNotFoundError(f"No MuseLang source files found in {source_path}")
    return files
