"""Tokens and source locations for the MuseLang frontend."""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum, auto

from .model import SourceSpan


class TokenKind(Enum):
    IDENT = auto()
    STRING = auto()
    INTEGER = auto()
    FLOAT = auto()
    NEWLINE = auto()
    INDENT = auto()
    DEDENT = auto()
    EQUAL = auto()
    EQUAL_EQUAL = auto()
    NOT_EQUAL = auto()
    GREATER = auto()
    GREATER_EQUAL = auto()
    LESS = auto()
    LESS_EQUAL = auto()
    PLUS_EQUAL = auto()
    MINUS_EQUAL = auto()
    ARROW = auto()
    DOT = auto()
    LPAREN = auto()
    RPAREN = auto()
    EOF = auto()


@dataclass(frozen=True, slots=True)
class Token:
    kind: TokenKind
    lexeme: str
    value: str | int | float | None
    span: SourceSpan

