"""Convenience cursor over MuseLang tokens."""

from __future__ import annotations

from .errors import ParseError
from .tokens import Token, TokenKind


class TokenStream:
    def __init__(self, tokens: list[Token]):
        self.tokens = tokens
        self.index = 0

    def peek(self, offset: int = 0) -> Token:
        index = min(self.index + offset, len(self.tokens) - 1)
        return self.tokens[index]

    def take(self) -> Token:
        token = self.peek()
        if token.kind is not TokenKind.EOF:
            self.index += 1
        return token

    def at(self, kind: TokenKind, lexeme: str | None = None) -> bool:
        token = self.peek()
        return token.kind is kind and (lexeme is None or token.lexeme == lexeme)

    def at_keyword(self, keyword: str) -> bool:
        return self.at(TokenKind.IDENT, keyword)

    def match(self, kind: TokenKind, lexeme: str | None = None) -> Token | None:
        if not self.at(kind, lexeme):
            return None
        return self.take()

    def match_keyword(self, keyword: str) -> Token | None:
        return self.match(TokenKind.IDENT, keyword)

    def expect(self, kind: TokenKind, description: str, lexeme: str | None = None) -> Token:
        if self.at(kind, lexeme):
            return self.take()
        token = self.peek()
        found = token.lexeme or token.kind.name.lower()
        raise ParseError(f"{token.span.location}: expected {description}, found {found!r}")

    def expect_keyword(self, keyword: str) -> Token:
        return self.expect(TokenKind.IDENT, repr(keyword), keyword)

    def expect_identifier(self, description: str = "identifier") -> Token:
        return self.expect(TokenKind.IDENT, description)

    def error(self, message: str, token: Token | None = None) -> ParseError:
        target = token or self.peek()
        return ParseError(f"{target.span.location}: {message}")

