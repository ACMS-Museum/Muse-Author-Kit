"""MuseLang command-line interface."""

from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path

from .compiler import build_bundle
from .emitter import emit_batch
from .errors import MuseLangError
from .live import load_live_snapshot
from .parser import parse_source_path
from .validator import validate_document


def _compare_live(document, snapshot: dict[str, set[str]]) -> list[str]:
    report: list[str] = []
    for room in document.rooms:
        if room.noun_id in snapshot["rooms"]:
            report.append(f"room:{room.noun_id}: already exists in live snapshot")
    for obj in document.objects:
        if obj.noun_id in snapshot["objects"]:
            report.append(f"object:{obj.noun_id}: already exists in live snapshot")
    for char in document.characters:
        if char.noun_id in snapshot["characters"]:
            report.append(f"character:{char.noun_id}: already exists in live snapshot")
    return report


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="muselang", description="MuseLang compiler")
    subparsers = parser.add_subparsers(dest="command", required=True)

    for mode in ("lint", "test", "dev", "prod"):
        mode_parser = subparsers.add_parser(mode)
        mode_parser.add_argument("source", help="Path to a MuseLang source file or folder")
        mode_parser.add_argument("--language", choices=("1.0",), default="1.0", help="MuseLang language version")
        mode_parser.add_argument("--live-json", dest="live_json", help="Path to a live-world JSON snapshot")
        mode_parser.add_argument("--out", help="Path to write the compiled MuseLang bundle")
        mode_parser.add_argument("--batch-out", help="Path to write the emitted Evennia batch file")
        mode_parser.add_argument("--report", help="Path to write a JSON report")

    runtime_parser = subparsers.add_parser("runtime-install")
    runtime_parser.add_argument("--language", choices=("1.0",), default="1.0", help="MuseLang runtime version")
    runtime_parser.add_argument("--game-root", default="muse-game", help="Path to the Evennia game root")
    runtime_parser.add_argument("--report", help="Path to write a JSON report")

    doctor_parser = subparsers.add_parser("doctor")
    doctor_parser.add_argument("--language", choices=("1.0",), default="1.0", help="MuseLang runtime version")
    doctor_parser.add_argument("--game-root", default="muse-game", help="Path to the Evennia game root")
    doctor_parser.add_argument("--report", help="Path to write a JSON report")
    return parser


def _diagnostic(severity: str, message: str, path: str | None = None, line: int | None = None) -> dict[str, object]:
    diagnostic: dict[str, object] = {"severity": severity, "message": message}
    if path is not None:
        diagnostic["path"] = path
    if line is not None:
        diagnostic["line"] = line
    return diagnostic


def _diagnostic_from_exception(exc: Exception, default_path: str | None = None) -> dict[str, object]:
    message = str(exc)
    match = re.match(r"^(?P<path>.*?):(?P<line>\d+):\s*(?P<message>.*)$", message)
    if match:
        return _diagnostic(
            "error",
            match.group("message"),
            path=match.group("path"),
            line=int(match.group("line")),
        )
    return _diagnostic("error", message, path=default_path)


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    try:
        if args.command == "runtime-install":
            from .installer import install_runtime

            result = {"command": "runtime-install", **install_runtime(args.game_root)}
            if args.report:
                Path(args.report).write_text(json.dumps(result, indent=2), encoding="utf-8")
            print(json.dumps(result, indent=2))
            return 0
        if args.command == "doctor":
            from .installer import doctor_runtime

            result = {"command": "doctor", **doctor_runtime(args.game_root)}
            if args.report:
                Path(args.report).write_text(json.dumps(result, indent=2), encoding="utf-8")
            print(json.dumps(result, indent=2))
            return 0

        source_path = Path(args.source)
        document = parse_source_path(source_path)
        warnings = validate_document(document)
        bundle = build_bundle(document)
        diagnostics = [_diagnostic("warning", warning, path=str(source_path)) for warning in warnings]
        result = {
            "mode": args.command,
            "language_version": args.language,
            "source": str(source_path),
            "source_files": document.source_paths,
            "summary": {
                "exits": sum(len(room.exits) for room in document.rooms),
                "rooms": len(document.rooms),
                "objects": len(document.objects),
                "characters": len(document.characters),
                "rules": len(document.rules),
            },
            "warnings": warnings,
            "diagnostics": diagnostics,
        }
        if args.command == "lint":
            result["status"] = "ok"
            if args.report:
                Path(args.report).write_text(json.dumps(result, indent=2), encoding="utf-8")
            print(json.dumps(result, indent=2))
            return 0
        if args.command in {"dev", "prod"}:
            snapshot = load_live_snapshot(args.live_json) if args.live_json else {"rooms": set(), "objects": set(), "characters": set()}
            result["live_conflicts"] = _compare_live(document, snapshot)
            if args.command == "prod":
                result["apply_status"] = "not_implemented"
                result["apply_message"] = "Prod mode bundle generation is implemented, but live Evennia apply is not wired yet."

        if args.out:
            out_path = Path(args.out)
        elif args.command in {"dev", "prod"}:
            out_path = _default_bundle_path(source_path)
        else:
            out_path = None
        if out_path is not None:
            out_path.write_text(json.dumps(bundle, indent=2), encoding="utf-8")
            result["bundle_path"] = str(out_path)
        if args.command == "prod" or args.batch_out:
            batch_path = Path(args.batch_out) if args.batch_out else _default_batch_path(source_path)
            batch_path.write_text(emit_batch(bundle), encoding="utf-8")
            result["batch_path"] = str(batch_path)
        if args.report:
            Path(args.report).write_text(json.dumps(result, indent=2), encoding="utf-8")
        print(json.dumps(result, indent=2))
        return 0
    except MuseLangError as exc:
        result = {
            "mode": args.command,
            "source": str(Path(args.source)) if hasattr(args, "source") else None,
            "status": "error",
            "diagnostics": [_diagnostic_from_exception(exc, getattr(args, "source", None))],
        }
        if args.command == "lint":
            print(json.dumps(result, indent=2))
        else:
            print(str(exc), file=sys.stderr)
        return 1
    except FileNotFoundError as exc:
        print(str(exc), file=sys.stderr)
        return 1


def _default_bundle_path(source_path: Path) -> Path:
    if source_path.is_dir():
        return source_path / f"{source_path.name}.muselang.json"
    return source_path.with_suffix(".muselang.json")


def _default_batch_path(source_path: Path) -> Path:
    if source_path.is_dir():
        return source_path / f"{source_path.name}.muselang.ev"
    return source_path.with_suffix(".muselang.ev")


if __name__ == "__main__":
    raise SystemExit(main())
