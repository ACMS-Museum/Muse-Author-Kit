"""Name resolution and semantic checks for MuseLang 1.0."""

from __future__ import annotations

import re
from dataclasses import dataclass

from .errors import ValidationError
from .model import (
    ConditionExpr,
    DialogueNode,
    GiveStmt,
    GotoStmt,
    HideStmt,
    IfStmt,
    MoveStmt,
    MuseDocument,
    NounDef,
    OptionStmt,
    SetStmt,
    ShowStmt,
    Statement,
    TextBlock,
    UntilStmt,
    WhileStmt,
)


_TWO_OBJECT_RULE = re.compile(
    r"^(?P<verb>[A-Za-z_][\w-]*)\s+(?P<direct>[A-Za-z_][\w-]*)\s+"
    r"(?P<prep>on|to)\s+(?P<target>[A-Za-z_][\w-]*)$"
)


@dataclass(slots=True)
class SymbolTable:
    nouns: dict[str, NounDef]
    rooms: set[str]
    objects: set[str]
    characters: set[str]


def resolve_document(document: MuseDocument) -> SymbolTable:
    """Resolve and validate static references in a V1 document."""

    symbols = _build_symbols(document)
    for noun in symbols.nouns.values():
        _validate_noun(noun, symbols)
    for rule in document.rules:
        match = _TWO_OBJECT_RULE.match(rule.header)
        if match:
            _require(match.group("direct"), symbols.nouns, rule.span.location, "rule direct object")
            _require(match.group("target"), symbols.nouns, rule.span.location, "rule target")
        _validate_statements(rule.statements, symbols, None)
    return symbols


def _build_symbols(document: MuseDocument) -> SymbolTable:
    nouns: dict[str, NounDef] = {}
    rooms = {room.noun_id for room in document.rooms}
    objects = {obj.noun_id for obj in document.objects}
    characters = {char.noun_id for char in document.characters}
    for noun in [*document.rooms, *document.objects, *document.characters]:
        if noun.noun_id in nouns:
            location = noun.span.location if noun.span else document.path
            raise ValidationError(f"{location}: duplicate noun id {noun.noun_id!r}")
        nouns[noun.noun_id] = noun
    return SymbolTable(nouns=nouns, rooms=rooms, objects=objects, characters=characters)


def _validate_noun(noun: NounDef, symbols: SymbolTable) -> None:
    location = noun.span.location if noun.span else noun.noun_id
    if noun.kind in {"object", "character"}:
        _require(noun.location or "", symbols.rooms, location, f"{noun.kind} location")
    if noun.kind == "room":
        for exit_def in noun.exits:
            _require(exit_def.destination_room_id, symbols.rooms, location, "exit destination")
            _validate_text_block(exit_def.description, symbols)

    aliases = [alias.casefold() for alias in noun.aliases]
    if len(aliases) != len(set(aliases)):
        raise ValidationError(f"{location}: {noun.kind} {noun.noun_id!r} has duplicate aliases")

    _validate_text_block(noun.description, symbols)
    command_words: dict[str, str] = {}
    for verb in noun.verbs:
        for word in [verb.name, *verb.aliases]:
            folded = word.casefold()
            if folded in command_words:
                raise ValidationError(
                    f"{verb.span.location}: command word {word!r} is already used by verb {command_words[folded]!r}"
                )
            command_words[folded] = verb.name
        _validate_statements(verb.statements, symbols, None)

    _validate_dialogue(noun, symbols)


def _validate_dialogue(noun: NounDef, symbols: SymbolTable) -> None:
    location = noun.span.location if noun.span else noun.noun_id
    if noun.dialogue_entry is None and noun.dialogue_nodes:
        raise ValidationError(f"{location}: dialogue nodes require a dialogue entry")
    nodes: dict[str, DialogueNode] = {}
    for node in noun.dialogue_nodes:
        if node.node_id in nodes:
            raise ValidationError(f"{node.span.location}: duplicate dialogue node {node.node_id!r}")
        nodes[node.node_id] = node
    if noun.dialogue_entry and noun.dialogue_entry not in nodes:
        raise ValidationError(f"{location}: dialogue entry {noun.dialogue_entry!r} is not defined")

    for node in noun.dialogue_nodes:
        option_ids: set[str] = set()
        hotkeys: set[str] = set()
        for statement in _walk(node.statements):
            if isinstance(statement, OptionStmt):
                if statement.option_id in option_ids:
                    raise ValidationError(f"{statement.span.location}: duplicate option id {statement.option_id!r}")
                option_ids.add(statement.option_id)
                if statement.hotkey:
                    hotkey = statement.hotkey.casefold()
                    if hotkey in hotkeys:
                        raise ValidationError(f"{statement.span.location}: duplicate dialogue hotkey {statement.hotkey!r}")
                    hotkeys.add(hotkey)
                _require(statement.target, nodes, statement.span.location, "dialogue option target")
                _validate_condition(statement.condition, symbols)
            elif isinstance(statement, GotoStmt):
                _require(statement.target, nodes, statement.span.location, "dialogue goto target")
        _validate_statements(node.statements, symbols, set(nodes))


def _validate_statements(
    statements: list[Statement],
    symbols: SymbolTable,
    dialogue_nodes: set[str] | None,
) -> None:
    for statement in statements:
        if isinstance(statement, IfStmt):
            for branch in statement.branches:
                _validate_condition(branch.condition, symbols)
                _validate_statements(branch.statements, symbols, dialogue_nodes)
            _validate_statements(statement.else_statements, symbols, dialogue_nodes)
        elif isinstance(statement, (WhileStmt, UntilStmt)):
            _validate_condition(statement.condition, symbols)
            _validate_statements(statement.statements, symbols, dialogue_nodes)
        elif isinstance(statement, MoveStmt):
            _require(statement.object_id, symbols.nouns, statement.span.location, "move object")
            _require(statement.location_id, symbols.rooms, statement.span.location, "move destination")
        elif isinstance(statement, GiveStmt):
            _require(statement.object_id, symbols.nouns, statement.span.location, "give object")
            _require(statement.character_id, symbols.characters, statement.span.location, "give recipient")
        elif isinstance(statement, (ShowStmt, HideStmt)):
            target = statement.target.split(".", 1)[0]
            _require(target, symbols.nouns, statement.span.location, f"{statement.kind} target")
        elif isinstance(statement, SetStmt) and "." in statement.target:
            target = statement.target.split(".", 1)[0]
            if target not in {"caller", "player", "this", "game", "world"}:
                _require(target, symbols.nouns, statement.span.location, "set target")
        elif isinstance(statement, GotoStmt) and dialogue_nodes is not None:
            _require(statement.target, dialogue_nodes, statement.span.location, "dialogue goto target")
        elif isinstance(statement, OptionStmt):
            _validate_condition(statement.condition, symbols)


def _validate_condition(expression: ConditionExpr | None, symbols: SymbolTable) -> None:
    if expression is None:
        return
    if expression.kind in {"and", "or"}:
        _validate_condition(expression.left, symbols)
        _validate_condition(expression.right, symbols)
    elif expression.kind == "not":
        _validate_condition(expression.left, symbols)
    elif expression.kind == "have" and expression.args:
        identifier = str(expression.args[0])
        if identifier not in symbols.nouns:
            raise ValidationError(f"Condition references unknown object {identifier!r}")
    elif expression.kind in {"truthy", "compare"} and expression.args:
        reference = str(expression.args[0])
        if "." in reference:
            noun_id = reference.split(".", 1)[0]
            if noun_id not in {"caller", "player", "this", "game", "world", "skill"} and noun_id not in symbols.nouns:
                raise ValidationError(f"Condition references unknown noun {noun_id!r}")


def _validate_text_block(block: TextBlock | None, symbols: SymbolTable) -> None:
    if block is None:
        return
    for branch in block.branches:
        _validate_condition(branch.condition, symbols)


def _walk(statements: list[Statement]):
    for statement in statements:
        yield statement
        if isinstance(statement, IfStmt):
            for branch in statement.branches:
                yield from _walk(branch.statements)
            yield from _walk(statement.else_statements)
        elif isinstance(statement, (WhileStmt, UntilStmt)):
            yield from _walk(statement.statements)


def _require(identifier: str, candidates, location: str, description: str) -> None:
    if identifier not in candidates:
        raise ValidationError(f"{location}: unknown {description} {identifier!r}")

