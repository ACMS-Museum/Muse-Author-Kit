"""Indentation-aware lexer for MuseLang source."""

from __future__ import annotations

from pathlib import Path

from .errors import ParseError
from .model import SourceSpan
from .tokens import Token, TokenKind


_TWO_CHAR_TOKENS = {
    "->": TokenKind.ARROW,
    "==": TokenKind.EQUAL_EQUAL,
    "!=": TokenKind.NOT_EQUAL,
    ">=": TokenKind.GREATER_EQUAL,
    "<=": TokenKind.LESS_EQUAL,
    "+=": TokenKind.PLUS_EQUAL,
    "-=": TokenKind.MINUS_EQUAL,
}

_ONE_CHAR_TOKENS = {
    "=": TokenKind.EQUAL,
    ">": TokenKind.GREATER,
    "<": TokenKind.LESS,
    ".": TokenKind.DOT,
    "(": TokenKind.LPAREN,
    ")": TokenKind.RPAREN,
}


class MuseLexer:
    """Convert MuseLang source into a source-aware token stream."""

    def __init__(self, path: str | Path, text: str):
        self.path = str(path)
        self.text = text

    def tokenize(self) -> list[Token]:
        tokens: list[Token] = []
        indent_stack = [0]
        lines = self.text.splitlines()

        for line_number, raw in enumerate(lines, start=1):
            if not raw.strip() or raw.lstrip().startswith("#"):
                continue
            leading = raw[: len(raw) - len(raw.lstrip(" \t"))]
            if "\t" in leading:
                raise self._error(line_number, leading.index("\t") + 1, "tabs are not allowed in indentation")
            indent = len(leading)
            if indent > indent_stack[-1]:
                indent_stack.append(indent)
                tokens.append(self._structural(TokenKind.INDENT, line_number, 1, indent + 1))
            elif indent < indent_stack[-1]:
                while indent < indent_stack[-1]:
                    indent_stack.pop()
                    tokens.append(self._structural(TokenKind.DEDENT, line_number, 1, indent + 1))
                if indent != indent_stack[-1]:
                    raise self._error(line_number, 1, f"inconsistent dedent to column {indent + 1}")

            self._tokenize_line(raw, line_number, indent, tokens)
            column = len(raw) + 1
            tokens.append(self._structural(TokenKind.NEWLINE, line_number, column, column))

        eof_line = len(lines) + 1
        while len(indent_stack) > 1:
            indent_stack.pop()
            tokens.append(self._structural(TokenKind.DEDENT, eof_line, 1, 1))
        tokens.append(self._structural(TokenKind.EOF, eof_line, 1, 1))
        return tokens

    def _tokenize_line(self, raw: str, line_number: int, position: int, tokens: list[Token]) -> None:
        length = len(raw)
        while position < length:
            char = raw[position]
            if char == " ":
                position += 1
                continue
            column = position + 1
            pair = raw[position : position + 2]
            if pair in _TWO_CHAR_TOKENS:
                tokens.append(self._token(_TWO_CHAR_TOKENS[pair], pair, pair, line_number, column, column + 2))
                position += 2
                continue
            if char in _ONE_CHAR_TOKENS:
                tokens.append(self._token(_ONE_CHAR_TOKENS[char], char, char, line_number, column, column + 1))
                position += 1
                continue
            if char == '"':
                token, position = self._string(raw, line_number, position)
                tokens.append(token)
                continue
            if char.isdigit():
                start = position
                while position < length and raw[position].isdigit():
                    position += 1
                kind = TokenKind.INTEGER
                if position < length and raw[position] == "." and position + 1 < length and raw[position + 1].isdigit():
                    position += 1
                    while position < length and raw[position].isdigit():
                        position += 1
                    kind = TokenKind.FLOAT
                lexeme = raw[start:position]
                value: int | float = int(lexeme) if kind is TokenKind.INTEGER else float(lexeme)
                tokens.append(self._token(kind, lexeme, value, line_number, start + 1, position + 1))
                continue
            if char.isalpha() or char == "_":
                start = position
                position += 1
                while position < length and (raw[position].isalnum() or raw[position] in {"_", "-"}):
                    position += 1
                lexeme = raw[start:position]
                tokens.append(self._token(TokenKind.IDENT, lexeme, lexeme, line_number, start + 1, position + 1))
                continue
            raise self._error(line_number, column, f"unexpected character {char!r}")

    def _string(self, raw: str, line_number: int, start: int) -> tuple[Token, int]:
        position = start + 1
        value: list[str] = []
        while position < len(raw):
            char = raw[position]
            if char == '"':
                end = position + 1
                lexeme = raw[start:end]
                return (
                    self._token(TokenKind.STRING, lexeme, "".join(value), line_number, start + 1, end + 1),
                    end,
                )
            if char == "\\":
                if position + 1 >= len(raw):
                    raise self._error(line_number, position + 1, "unterminated escape in string")
                escaped = raw[position + 1]
                if escaped in {'"', "\\"}:
                    value.append(escaped)
                else:
                    value.extend(("\\", escaped))
                position += 2
                continue
            value.append(char)
            position += 1
        raise self._error(line_number, start + 1, "unterminated string")

    def _token(
        self,
        kind: TokenKind,
        lexeme: str,
        value: str | int | float,
        line: int,
        column: int,
        end_column: int,
    ) -> Token:
        return Token(kind, lexeme, value, SourceSpan(self.path, line, column, line, end_column))

    def _structural(self, kind: TokenKind, line: int, column: int, end_column: int) -> Token:
        return Token(kind, "", None, SourceSpan(self.path, line, column, line, end_column))

    def _error(self, line: int, column: int, message: str) -> ParseError:
        return ParseError(f"{self.path}:{line}:{column}: {message}")


def lex_source(path: str | Path, text: str) -> list[Token]:
    """Lex a complete MuseLang source string."""

    return MuseLexer(path, text).tokenize()

