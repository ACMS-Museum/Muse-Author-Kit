"""MuseLang exceptions."""


class MuseLangError(Exception):
    """Base MuseLang error."""


class ParseError(MuseLangError):
    """Raised when MuseLang source cannot be parsed."""


class ValidationError(MuseLangError):
    """Raised when MuseLang source fails validation."""

