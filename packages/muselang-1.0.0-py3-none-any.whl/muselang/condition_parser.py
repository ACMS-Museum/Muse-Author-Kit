"""Recursive-descent parsing for MuseLang conditions."""

from __future__ import annotations

from .lexer import lex_source
from .model import ConditionExpr
from .token_stream import TokenStream
from .tokens import Token, TokenKind


_COMPARISONS = {
    TokenKind.EQUAL: "==",
    TokenKind.EQUAL_EQUAL: "==",
    TokenKind.NOT_EQUAL: "!=",
    TokenKind.GREATER_EQUAL: ">=",
    TokenKind.LESS_EQUAL: "<=",
    TokenKind.GREATER: ">",
    TokenKind.LESS: "<",
}


class ConditionParser:
    """Parse one condition from a shared MuseLang token stream."""

    def __init__(self, stream: TokenStream, stop_kinds: set[TokenKind] | None = None):
        self.stream = stream
        self.stop_kinds = stop_kinds or {TokenKind.NEWLINE, TokenKind.EOF}

    def parse(self) -> ConditionExpr:
        if self._at_stop():
            raise self.stream.error("empty condition")
        expression = self._parse_or()
        if not self._at_stop():
            raise self.stream.error(f"unexpected token {self.stream.peek().lexeme!r} in condition")
        return expression

    def _at_stop(self) -> bool:
        return self.stream.peek().kind in self.stop_kinds

    def _parse_or(self) -> ConditionExpr:
        expression = self._parse_and()
        while self.stream.match_keyword("or"):
            expression = ConditionExpr(kind="or", left=expression, right=self._parse_and())
        return expression

    def _parse_and(self) -> ConditionExpr:
        expression = self._parse_not()
        while self.stream.match_keyword("and"):
            expression = ConditionExpr(kind="and", left=expression, right=self._parse_not())
        return expression

    def _parse_not(self) -> ConditionExpr:
        if self.stream.match_keyword("not"):
            return ConditionExpr(kind="not", left=self._parse_not())
        return self._parse_primary()

    def _parse_primary(self) -> ConditionExpr:
        if self.stream.match(TokenKind.LPAREN):
            expression = self._parse_or()
            self.stream.expect(TokenKind.RPAREN, "')'")
            return expression
        return self._parse_predicate_or_comparison()

    def _parse_predicate_or_comparison(self) -> ConditionExpr:
        token = self.stream.expect_identifier("predicate or reference")
        if token.lexeme in {"have", "flag", "topic", "selected"}:
            return ConditionExpr(kind=token.lexeme, args=(self._parse_reference(),))

        reference = self._parse_reference(token)
        operator = self.stream.peek()
        if operator.kind in _COMPARISONS:
            self.stream.take()
            value = self._parse_value()
            return ConditionExpr(kind="compare", args=(reference, _COMPARISONS[operator.kind], value))
        return ConditionExpr(kind="truthy", args=(reference,))

    def _parse_reference(self, first: Token | None = None) -> str:
        parts = [(first or self.stream.expect_identifier()).lexeme]
        while self.stream.match(TokenKind.DOT):
            parts.append(self.stream.expect_identifier("identifier after '.'").lexeme)
        return ".".join(parts)

    def _parse_value(self) -> object:
        token = self.stream.peek()
        if token.kind is TokenKind.STRING:
            return self.stream.take().value
        if token.kind in {TokenKind.INTEGER, TokenKind.FLOAT}:
            return self.stream.take().value
        if token.kind is TokenKind.IDENT:
            if token.lexeme == "true":
                self.stream.take()
                return True
            if token.lexeme == "false":
                self.stream.take()
                return False
            return self._parse_reference()
        raise self.stream.error("expected comparison value")


def parse_condition(text: str) -> ConditionExpr:
    """Parse a standalone condition using the common lexer."""

    stream = TokenStream(lex_source("<condition>", text))
    expression = ConditionParser(stream).parse()
    stream.match(TokenKind.NEWLINE)
    stream.expect(TokenKind.EOF, "end of condition")
    return expression

