"""Evennia batch emission for MuseLang bundles."""

from __future__ import annotations

from typing import Any


def emit_batch(bundle: dict[str, Any]) -> str:
    """Emit a full Evennia batch file from a MuseLang bundle."""

    nouns = bundle.get("nouns", [])
    rooms = [noun for noun in nouns if noun.get("kind") == "room"]
    others = [noun for noun in nouns if noun.get("kind") in {"object", "character"}]
    lines: list[str] = []

    def emit(command: str) -> None:
        lines.append(command)
        lines.append("#")

    for room in rooms:
        emit(f"@dig {_display_name(room)};{_alias_chain(room)}")
        emit(f"@tel me = {room['id']}")
        _emit_definition(room, emit)

    for exit_def in bundle.get("exits", []) or []:
        _emit_exit(exit_def, emit)

    for noun in others:
        emit(f"@create {_display_name(noun)};{_alias_chain(noun)}")
        _emit_definition(noun, emit)
        if noun.get("location"):
            emit(f"@tel {noun['id']} = {noun['location']}")

    return "\n".join(lines).rstrip() + "\n"


def _emit_definition(noun: dict[str, Any], emit) -> None:
    noun_id = noun["id"]
    description = noun.get("description")
    if isinstance(description, dict):
        fallback = _description_fallback(description)
        if fallback:
            target = "here" if noun.get("kind") == "room" else noun_id
            emit(f"@desc {target} = {fallback}")
        emit(f"set {noun_id}/description:muse = {repr(description)}")
    elif description:
        target = "here" if noun.get("kind") == "room" else noun_id
        emit(f"@desc {target} = {description}")
    if noun.get("portable") is True:
        emit(f"@lock {noun_id} = get:true()")
    elif noun.get("portable") is False:
        emit(f"@lock {noun_id} = get:false()")
    for tag in noun.get("tags", []) or []:
        emit(f"@tag {noun_id} = {tag}")
    if noun.get("state"):
        for key, value in noun["state"].items():
            emit(f"set {noun_id}/{key}:muse = {repr(value)}")
    interactions = noun.get("interactions") or []
    if interactions:
        emit(f"set {noun_id}/interactions:muse = {repr(interactions)}")
    rules = noun.get("macro_rules") or []
    if rules:
        emit(f"set {noun_id}/macro_rules:muse = {repr(rules)}")
    dialogue = noun.get("dialogue")
    if dialogue:
        emit(f"set {noun_id}/dialogue:muse = {repr(dialogue)}")
    for behaviour in noun.get("required_behaviours", []) or []:
        emit(f'py self.search("{noun_id}").cmdset.add("{behaviour}", persistent=True)')


def _emit_exit(exit_def: dict[str, Any], emit) -> None:
    source = exit_def["source_room"]
    name = exit_def["exit_name"]
    aliases = [str(alias) for alias in exit_def.get("aliases", []) or []]
    alias_suffix = "".join(f";{alias}" for alias in aliases)
    emit(f"@tel me = {source}")
    emit(f"@open {name}{alias_suffix} = {exit_def['destination_room']}")
    description = exit_def.get("description")
    if isinstance(description, dict):
        fallback = _description_fallback(description)
        if fallback:
            emit(f"@desc {name} = {fallback}")
        emit(f"set {name}/description:muse = {repr(description)}")
    elif description:
        emit(f"@desc {name} = {description}")
    for key, value in (exit_def.get("state") or {}).items():
        emit(f"set {name}/{key}:muse = {repr(value)}")
    for tag in exit_def.get("tags", []) or []:
        emit(f"@tag {name} = {tag}")


def _display_name(noun: dict[str, Any]) -> str:
    return str(noun.get("name") or noun.get("id"))


def _alias_chain(noun: dict[str, Any]) -> str:
    parts = [str(noun["id"])]
    for alias in noun.get("aliases", []) or []:
        alias_text = str(alias)
        if alias_text not in parts:
            parts.append(alias_text)
    return ";".join(parts)


def _description_fallback(description: dict[str, Any]) -> str | None:
    branches = description.get("branches")
    if not isinstance(branches, list) or not branches:
        return None
    first = branches[0]
    if not isinstance(first, dict):
        return None
    text = first.get("text")
    return str(text) if isinstance(text, str) and text else None

