"""Runtime installation and verification for MuseLang."""

from __future__ import annotations

from dataclasses import asdict, dataclass
from importlib import resources
from pathlib import Path


RUNTIME_MODULES = (
    "runtime_version.py",
    "metadata_access.py",
    "runtime_context.py",
    "condition_eval.py",
    "action_eval.py",
    "simple_message.py",
    "conditional_verbs.py",
    "dialogue.py",
    "use_on_target.py",
    "python_call.py",
)


@dataclass(slots=True)
class RuntimeCheck:
    module: str
    status: str
    detail: str


def runtime_target_dir(game_root: str | Path) -> Path:
    """Return the target behaviours/common directory for a game root."""

    return Path(game_root) / "behaviours" / "common"


def install_runtime(game_root: str | Path) -> dict[str, object]:
    """Install bundled MuseLang runtime helper modules into a game root."""

    target_dir = runtime_target_dir(game_root)
    target_dir.mkdir(parents=True, exist_ok=True)
    installed: list[str] = []
    updated: list[str] = []
    unchanged: list[str] = []
    for module in RUNTIME_MODULES:
        source_text = _template_text(module)
        target_path = target_dir / module
        if not target_path.exists():
            target_path.write_text(source_text, encoding="utf-8")
            installed.append(module)
            continue
        current = target_path.read_text(encoding="utf-8")
        if current != source_text:
            target_path.write_text(source_text, encoding="utf-8")
            updated.append(module)
        else:
            unchanged.append(module)
    return {
        "language_version": "1.0",
        "runtime_api": 1,
        "game_root": str(Path(game_root)),
        "target_dir": str(target_dir),
        "installed": installed,
        "updated": updated,
        "unchanged": unchanged,
    }


def doctor_runtime(game_root: str | Path) -> dict[str, object]:
    """Verify that a game root contains the expected MuseLang runtime."""

    target_dir = runtime_target_dir(game_root)
    checks: list[RuntimeCheck] = []
    healthy = True
    for module in RUNTIME_MODULES:
        target_path = target_dir / module
        if not target_path.exists():
            checks.append(RuntimeCheck(module=module, status="missing", detail="Runtime module is not installed"))
            healthy = False
            continue
        expected = _template_text(module)
        current = target_path.read_text(encoding="utf-8")
        if current != expected:
            checks.append(RuntimeCheck(module=module, status="out_of_date", detail="Runtime module differs from bundled MuseLang version"))
            healthy = False
        else:
            checks.append(RuntimeCheck(module=module, status="ok", detail="Runtime module matches bundled version"))
    return {
        "language_version": "1.0",
        "runtime_api": 1,
        "game_root": str(Path(game_root)),
        "target_dir": str(target_dir),
        "healthy": healthy,
        "checks": [asdict(check) for check in checks],
    }


def _template_text(module: str) -> str:
    package = resources.files("muselang").joinpath("runtime_templates", "common", module)
    return package.read_text(encoding="utf-8")
