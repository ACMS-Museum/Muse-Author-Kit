"""Core MuseLang datamodels."""

from __future__ import annotations

from dataclasses import dataclass, field


@dataclass(frozen=True, slots=True)
class SourceSpan:
    path: str
    line: int
    column: int = 1
    end_line: int | None = None
    end_column: int | None = None

    @property
    def location(self) -> str:
        return f"{self.path}:{self.line}:{self.column}"


@dataclass(slots=True)
class ConditionExpr:
    kind: str
    value: str | bool | int | float | None = None
    left: "ConditionExpr | None" = None
    right: "ConditionExpr | None" = None
    args: tuple[object, ...] = ()


@dataclass(slots=True)
class Statement:
    kind: str
    span: SourceSpan


@dataclass(slots=True)
class SayStmt(Statement):
    text: str


@dataclass(slots=True)
class HintStmt(Statement):
    text: str


@dataclass(slots=True)
class SetStmt(Statement):
    target: str
    value: str | bool | int | float


@dataclass(slots=True)
class GotoStmt(Statement):
    target: str


@dataclass(slots=True)
class CallStmt(Statement):
    target: str


@dataclass(slots=True)
class EndStmt(Statement):
    pass


@dataclass(slots=True)
class WhileStmt(Statement):
    condition: ConditionExpr
    statements: list[Statement]


@dataclass(slots=True)
class UntilStmt(Statement):
    condition: ConditionExpr
    statements: list[Statement]


@dataclass(slots=True)
class MoveStmt(Statement):
    object_id: str
    location_id: str


@dataclass(slots=True)
class GiveStmt(Statement):
    object_id: str
    character_id: str


@dataclass(slots=True)
class ShowStmt(Statement):
    target: str


@dataclass(slots=True)
class HideStmt(Statement):
    target: str


@dataclass(slots=True)
class OptionStmt(Statement):
    option_id: str
    label: str
    hotkey: str | None
    target: str
    condition: ConditionExpr | None = None


@dataclass(slots=True)
class IfBranch:
    condition: ConditionExpr
    statements: list[Statement]
    span: SourceSpan


@dataclass(slots=True)
class IfStmt(Statement):
    branches: list[IfBranch] = field(default_factory=list)
    else_statements: list[Statement] = field(default_factory=list)


@dataclass(slots=True)
class TextBranch:
    condition: ConditionExpr | None
    lines: list[str]
    span: SourceSpan


@dataclass(slots=True)
class TextBlock:
    branches: list[TextBranch] = field(default_factory=list)


StatementLike = (
    SayStmt
    | HintStmt
    | SetStmt
    | GotoStmt
    | CallStmt
    | EndStmt
    | WhileStmt
    | UntilStmt
    | MoveStmt
    | GiveStmt
    | ShowStmt
    | HideStmt
    | OptionStmt
    | IfStmt
)


@dataclass(slots=True)
class ExitDef:
    source_room_id: str
    exit_name: str
    destination_room_id: str
    aliases: list[str] = field(default_factory=list)
    description: TextBlock | None = None
    tags: list[str] = field(default_factory=list)
    state: dict[str, str | bool | int | float] = field(default_factory=dict)
    span: SourceSpan | None = None


@dataclass(slots=True)
class VerbDef:
    name: str
    aliases: list[str]
    statements: list[Statement]
    span: SourceSpan


@dataclass(slots=True)
class DialogueNode:
    node_id: str
    statements: list[Statement]
    span: SourceSpan


@dataclass(slots=True)
class RuleDef:
    header: str
    statements: list[Statement]
    span: SourceSpan


@dataclass(slots=True)
class NounDef:
    kind: str
    noun_id: str
    name: str | None
    location: str | None
    aliases: list[str] = field(default_factory=list)
    description: TextBlock | None = None
    tags: list[str] = field(default_factory=list)
    state: dict[str, str | bool | int | float] = field(default_factory=dict)
    portable: bool | None = None
    type_id: str | None = None
    exits: list[ExitDef] = field(default_factory=list)
    verbs: list[VerbDef] = field(default_factory=list)
    dialogue_entry: str | None = None
    dialogue_nodes: list[DialogueNode] = field(default_factory=list)
    span: SourceSpan | None = None


@dataclass(slots=True)
class MuseDocument:
    path: str
    source_paths: list[str] = field(default_factory=list)
    rooms: list[NounDef] = field(default_factory=list)
    objects: list[NounDef] = field(default_factory=list)
    characters: list[NounDef] = field(default_factory=list)
    rules: list[RuleDef] = field(default_factory=list)

