"""Live world snapshot helpers for MuseLang."""

from __future__ import annotations

import json
from pathlib import Path


def load_live_snapshot(path: str | None) -> dict[str, set[str]]:
    """Load a live-world snapshot from JSON if available."""

    if not path:
        return {"rooms": set(), "objects": set(), "characters": set()}
    snapshot_path = Path(path)
    if not snapshot_path.exists():
        raise FileNotFoundError(f"Live snapshot not found: {snapshot_path}")
    payload = json.loads(snapshot_path.read_text(encoding="utf-8"))
    core = payload.get("core", payload)
    return {
        "rooms": _extract_ids(core.get("rooms", [])),
        "objects": _extract_ids(core.get("objects", [])),
        "characters": _extract_ids(core.get("characters", [])),
    }


def _extract_ids(items: object) -> set[str]:
    ids: set[str] = set()
    if not isinstance(items, list):
        return ids
    for item in items:
        if not isinstance(item, dict):
            continue
        for key in ("source_id", "id", "key"):
            value = item.get(key)
            if isinstance(value, str) and value:
                ids.add(value.split(":", 1)[-1])
                break
    return ids

