"""MuseLang validation."""

from __future__ import annotations

from .errors import ValidationError
from .model import DialogueNode, GotoStmt, IfStmt, MuseDocument, NounDef, OptionStmt, Statement, UntilStmt, WhileStmt
from .resolver import resolve_document


def _span_prefix(span) -> str:
    if span is None:
        return ""
    return f"{span.path}:{span.line}: "


def _fail(span, message: str) -> None:
    raise ValidationError(f"{_span_prefix(span)}{message}")


def _walk_statements(statements: list[Statement]) -> list[Statement]:
    flat: list[Statement] = []
    for statement in statements:
        flat.append(statement)
        if isinstance(statement, IfStmt):
            for branch in statement.branches:
                flat.extend(_walk_statements(branch.statements))
            flat.extend(_walk_statements(statement.else_statements))
        elif isinstance(statement, (WhileStmt, UntilStmt)):
            flat.extend(_walk_statements(statement.statements))
    return flat


def validate_document(document: MuseDocument) -> list[str]:
    """Validate a MuseLang document and return warnings."""

    warnings: list[str] = []
    noun_ids: set[str] = set()
    rooms = {room.noun_id for room in document.rooms}
    for noun in [*document.rooms, *document.objects, *document.characters]:
        if noun.noun_id in noun_ids:
            _fail(noun.span, f"Duplicate noun id {noun.noun_id!r}")
        noun_ids.add(noun.noun_id)
        if noun.kind in {"object", "character"} and noun.location not in rooms:
            _fail(noun.span, f"{noun.kind.title()} {noun.noun_id!r} references unknown room {noun.location!r}")
        if len(noun.aliases) != len(set(noun.aliases)):
            _fail(noun.span, f"{noun.kind.title()} {noun.noun_id!r} has duplicate aliases")
        if noun.kind == "room":
            seen_exit_names: set[str] = set()
            for exit_def in noun.exits:
                if exit_def.source_room_id != noun.noun_id:
                    _fail(exit_def.span, f"Exit {exit_def.exit_name!r} references unexpected source room {exit_def.source_room_id!r}")
                if exit_def.destination_room_id not in rooms:
                    _fail(exit_def.span, f"Exit {exit_def.exit_name!r} references unknown destination room {exit_def.destination_room_id!r}")
                if exit_def.exit_name in seen_exit_names:
                    _fail(exit_def.span, f"Duplicate exit {exit_def.exit_name!r} for room {noun.noun_id!r}")
                seen_exit_names.add(exit_def.exit_name)
                if len(exit_def.aliases) != len(set(exit_def.aliases)):
                    _fail(exit_def.span, f"Exit {exit_def.exit_name!r} has duplicate aliases")
        _validate_statement_blocks(noun.verbs, noun.dialogue_nodes)
        _validate_dialogue(noun)
    _validate_rules(document)
    resolve_document(document)
    return warnings


def _validate_statement_blocks(verbs, dialogue_nodes) -> None:
    for verb in verbs:
        _validate_statement_list(verb.statements, f"Verb {verb.name!r}")
    for node in dialogue_nodes:
        _validate_statement_list(node.statements, f"Dialogue node {node.node_id!r}")


def _validate_statement_list(statements: list[Statement], context: str) -> None:
    for statement in _walk_statements(statements):
        if isinstance(statement, (WhileStmt, UntilStmt)) and not statement.statements:
            _fail(statement.span, f"{context} contains an empty loop block")


def _validate_rules(document: MuseDocument) -> None:
    for rule in document.rules:
        _validate_statement_list(rule.statements, f"Rule {rule.header!r}")


def _validate_dialogue(noun: NounDef) -> None:
    if noun.dialogue_entry is None and noun.dialogue_nodes:
        _fail(noun.span, f"{noun.kind.title()} {noun.noun_id!r} defines dialogue nodes without a dialogue entry")
    node_map: dict[str, DialogueNode] = {}
    for node in noun.dialogue_nodes:
        if node.node_id in node_map:
            _fail(node.span, f"{noun.kind.title()} {noun.noun_id!r} has duplicate dialogue node {node.node_id!r}")
        node_map[node.node_id] = node
    if noun.dialogue_entry and noun.dialogue_entry not in node_map:
        _fail(noun.span, f"{noun.kind.title()} {noun.noun_id!r} dialogue entry {noun.dialogue_entry!r} is not defined")
    for node in noun.dialogue_nodes:
        seen_hotkeys: set[str] = set()
        seen_option_ids: set[str] = set()
        for statement in _walk_statements(node.statements):
            if isinstance(statement, OptionStmt):
                if statement.option_id in seen_option_ids:
                    _fail(node.span, f"Dialogue node {node.node_id!r} has duplicate option id {statement.option_id!r}")
                seen_option_ids.add(statement.option_id)
                if statement.hotkey:
                    hotkey = statement.hotkey.lower()
                    if hotkey in seen_hotkeys:
                        _fail(node.span, f"Dialogue node {node.node_id!r} has duplicate hotkey {statement.hotkey!r}")
                    seen_hotkeys.add(hotkey)
                if statement.target not in node_map:
                    _fail(node.span, f"Dialogue node {node.node_id!r} references unknown target {statement.target!r}")
            if isinstance(statement, GotoStmt) and statement.target not in node_map:
                _fail(node.span, f"Dialogue node {node.node_id!r} uses unknown goto target {statement.target!r}")
