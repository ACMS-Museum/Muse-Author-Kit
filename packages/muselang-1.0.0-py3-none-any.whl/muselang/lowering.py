"""Lower MuseLang documents into runtime-oriented payloads."""

from __future__ import annotations

import re

from .ir import V1Noun, V1Program, V1Rule
from .model import (
    CallStmt,
    ConditionExpr,
    DialogueNode,
    EndStmt,
    ExitDef,
    GiveStmt,
    GotoStmt,
    HideStmt,
    HintStmt,
    IfStmt,
    MoveStmt,
    OptionStmt,
    SayStmt,
    SetStmt,
    ShowStmt,
    Statement,
    TextBlock,
    UntilStmt,
    VerbDef,
    WhileStmt,
)


SIMPLE_MESSAGE_BEHAVIOUR = "behaviours.common.simple_message.SimpleMessage"
CONDITIONAL_BEHAVIOUR = "behaviours.common.conditional_verbs.ConditionalVerbCmdSet"
DIALOGUE_BEHAVIOUR = "behaviours.common.dialogue.DialogueCmdSet"
USE_ON_TARGET_BEHAVIOUR = "behaviours.common.use_on_target.UseOnTargetCmdSet"
PYTHON_CALL_BEHAVIOUR = "behaviours.common.python_call.PythonCallCmdSet"


def lower_document(document: V1Program) -> dict[str, object]:
    """Lower a parsed document into a runtime-oriented payload."""

    rules = [_lower_rule(rule) for rule in document.rules]
    rules_by_target: dict[str, list[dict[str, object]]] = {}
    for rule in rules:
        target = rule.get("target_object")
        if isinstance(target, str) and target:
            rules_by_target.setdefault(target, []).append(rule)
    exits: list[dict[str, object]] = []
    nouns: list[dict[str, object]] = []
    for room in document.rooms:
        room_payload = _lower_noun(room, rules_by_target.get(room.noun_id, []))
        room_exits = [_lower_exit(exit_def) for exit_def in room.exits]
        room_payload["exits"] = room_exits
        nouns.append(room_payload)
        exits.extend(room_exits)
    nouns.extend(
        _lower_noun(noun, rules_by_target.get(noun.noun_id, []))
        for noun in [*document.objects, *document.characters]
    )
    return {
        "language_version": "1.0",
        "bundle_schema": 1,
        "runtime_api": 1,
        "source": document.path,
        "exits": exits,
        "nouns": nouns,
        "rules": rules,
    }


def _lower_exit(exit_def: ExitDef) -> dict[str, object]:
    return {
        "kind": "exit",
        "source_room": exit_def.source_room_id,
        "exit_name": exit_def.exit_name,
        "destination_room": exit_def.destination_room_id,
        "aliases": list(exit_def.aliases),
        "description": _lower_text_block(exit_def.description),
        "tags": list(exit_def.tags),
        "state": dict(exit_def.state),
    }


def _lower_noun(noun: V1Noun, attached_rules: list[dict[str, object]]) -> dict[str, object]:
    interactions = [_lower_verb(verb) for verb in noun.verbs]
    dialogue = _lower_dialogue(noun)
    if dialogue is not None and not any(item["verb"] == "talk" for item in interactions):
        interactions.append(
            {
                "id": "talk",
                "verb": "talk",
                "aliases": ["greet"],
                "behaviour": DIALOGUE_BEHAVIOUR,
                "hint": None,
                "status": None,
                "message": None,
                "config": {"dialogue_entry": noun.dialogue_entry},
            }
        )
    required_behaviours = sorted(
        {
            interaction["behaviour"]
            for interaction in interactions
        }
        | {
            str(rule["handler"])
            for rule in attached_rules
            if rule.get("handler")
        }
        | (
            {dialogue["behaviour"]}
            if dialogue is not None
            else set()
        )
    )
    return {
        "kind": noun.kind,
        "id": noun.noun_id,
        "name": noun.name,
        "location": noun.location,
        "aliases": list(noun.aliases),
        "description": _lower_text_block(noun.description),
        "tags": list(noun.tags),
        "state": dict(noun.state),
        "portable": noun.portable,
        "type_id": noun.type_id,
        "interactions": interactions,
        "macro_rules": attached_rules,
        "dialogue": dialogue,
        "required_behaviours": required_behaviours,
    }


def _lower_text_block(block: TextBlock | None) -> object:
    if block is None:
        return None
    if len(block.branches) == 1 and block.branches[0].condition is None:
        return "\n".join(block.branches[0].lines)
    return {
        "kind": "conditional_text",
        "branches": [
            {
                "condition": _lower_condition(branch.condition) if branch.condition else None,
                "text": "\n".join(branch.lines),
            }
            for branch in block.branches
        ],
    }


def _lower_verb(verb: VerbDef) -> dict[str, object]:
    if _is_simple_message(verb.statements):
        statement = verb.statements[0]
        message = statement.text if isinstance(statement, (SayStmt, HintStmt)) else None
        hint = statement.text if isinstance(statement, HintStmt) else None
        return {
            "id": verb.name,
            "verb": verb.name,
            "aliases": list(verb.aliases),
            "behaviour": SIMPLE_MESSAGE_BEHAVIOUR,
            "hint": hint,
            "status": None,
            "message": message,
            "config": {},
        }
    if len(verb.statements) == 1 and isinstance(verb.statements[0], CallStmt):
        return {
            "id": verb.name,
            "verb": verb.name,
            "aliases": list(verb.aliases),
            "behaviour": PYTHON_CALL_BEHAVIOUR,
            "hint": None,
            "status": None,
            "message": None,
            "config": {"call_target": verb.statements[0].target},
        }
    return {
        "id": verb.name,
        "verb": verb.name,
        "aliases": list(verb.aliases),
        "behaviour": CONDITIONAL_BEHAVIOUR,
        "hint": None,
        "status": None,
        "message": None,
        "config": {"program": _lower_statements(verb.statements)},
    }


def _is_simple_message(statements: list[Statement]) -> bool:
    return len(statements) == 1 and isinstance(statements[0], (SayStmt, HintStmt))


def _lower_dialogue(noun: V1Noun) -> dict[str, object] | None:
    if noun.dialogue_entry is None:
        return None
    nodes = {node.node_id: _lower_dialogue_node(node) for node in noun.dialogue_nodes}
    return {
        "behaviour": DIALOGUE_BEHAVIOUR,
        "entry": noun.dialogue_entry,
        "nodes": nodes,
    }


def _lower_dialogue_node(node: DialogueNode) -> dict[str, object]:
    says: list[str] = []
    options: list[dict[str, object]] = []
    actions: list[object] = []
    for statement in node.statements:
        if isinstance(statement, SayStmt):
            says.append(statement.text)
            continue
        if isinstance(statement, OptionStmt):
            options.append(
                {
                    "id": statement.option_id,
                    "label": statement.label,
                    "hotkey": statement.hotkey,
                    "condition": _lower_condition(statement.condition) if statement.condition else None,
                    "target": statement.target,
                }
            )
            continue
        actions.extend(_lower_statements([statement]))
    payload: dict[str, object] = {"program": _lower_statements(node.statements)}
    if says:
        payload["say"] = says
    if options:
        payload["options"] = options
    if actions:
        payload["actions"] = actions
    return payload


def _lower_rule(rule: V1Rule) -> dict[str, object]:
    header = rule.header
    match = re.match(r"^(?P<verb>\S+)\s+(?P<direct>\S+)\s+(?P<prep>on|to)\s+(?P<target>\S+)$", header)
    if match:
        return {
            "id": _rule_id_from_header(header),
            "verb": match.group("verb"),
            "direct_object": match.group("direct"),
            "preposition": match.group("prep"),
            "target_object": match.group("target"),
            "handler": USE_ON_TARGET_BEHAVIOUR,
            "program": _lower_statements(rule.statements),
        }
    return {
        "id": _rule_id_from_header(header),
        "name": header,
        "handler": CONDITIONAL_BEHAVIOUR,
        "program": _lower_statements(rule.statements),
    }


def _rule_id_from_header(header: str) -> str:
    return re.sub(r"[^a-z0-9]+", "_", header.lower()).strip("_") or "rule"


def _lower_statements(statements: list[Statement]) -> list[object]:
    program: list[object] = []
    for statement in statements:
        if isinstance(statement, SayStmt):
            program.append(["say", statement.text])
        elif isinstance(statement, HintStmt):
            program.append(["hint", statement.text])
        elif isinstance(statement, SetStmt):
            program.append(["set", statement.target, statement.value])
        elif isinstance(statement, GotoStmt):
            program.append(["goto", statement.target])
        elif isinstance(statement, CallStmt):
            program.append(["call", statement.target])
        elif isinstance(statement, EndStmt):
            program.append(["end"])
        elif isinstance(statement, MoveStmt):
            program.append(["move", statement.object_id, statement.location_id])
        elif isinstance(statement, GiveStmt):
            program.append(["give", statement.object_id, statement.character_id])
        elif isinstance(statement, ShowStmt):
            program.append(["show", statement.target])
        elif isinstance(statement, HideStmt):
            program.append(["hide", statement.target])
        elif isinstance(statement, OptionStmt):
            program.append(
                [
                    "option",
                    statement.option_id,
                    statement.label,
                    statement.hotkey,
                    _lower_condition(statement.condition) if statement.condition else None,
                    statement.target,
                ]
            )
        elif isinstance(statement, IfStmt):
            program.append(
                {
                    "op": "if",
                    "branches": [
                        {
                            "condition": _lower_condition(branch.condition),
                            "then": _lower_statements(branch.statements),
                        }
                        for branch in statement.branches
                    ],
                    "else": _lower_statements(statement.else_statements),
                }
            )
        elif isinstance(statement, WhileStmt):
            program.append(
                {
                    "op": "while",
                    "condition": _lower_condition(statement.condition),
                    "body": _lower_statements(statement.statements),
                }
            )
        elif isinstance(statement, UntilStmt):
            program.append(
                {
                    "op": "until",
                    "condition": _lower_condition(statement.condition),
                    "body": _lower_statements(statement.statements),
                }
            )
    return program


def _lower_condition(expr: ConditionExpr) -> object:
    if expr is None:
        return None
    if expr.kind in {"and", "or"}:
        return [expr.kind, _lower_condition(expr.left), _lower_condition(expr.right)]
    if expr.kind == "not":
        return ["not", _lower_condition(expr.left)]
    if expr.kind == "compare":
        return ["compare", *expr.args]
    if expr.kind in {"have", "flag", "topic", "selected"}:
        return [expr.kind, *expr.args]
    if expr.kind == "truthy":
        return ["truthy", *expr.args]
    return [expr.kind, *expr.args]
