"""MuseLang compilation helpers."""

from __future__ import annotations

from .model import MuseDocument
from .ir import normalize_document
from .lowering import lower_document
from .resolver import resolve_document


def build_bundle(document: MuseDocument) -> dict[str, object]:
    """Build a runtime-oriented MuseLang bundle from a parsed document."""

    symbols = resolve_document(document)
    program = normalize_document(document, symbols)
    return lower_document(program)
