"""Normalized intermediate representation for MuseLang 1.0."""

from __future__ import annotations

from dataclasses import dataclass

from .model import DialogueNode, ExitDef, MuseDocument, NounDef, RuleDef, SourceSpan, Statement, TextBlock, VerbDef
from .resolver import SymbolTable


@dataclass(frozen=True, slots=True)
class V1Noun:
    kind: str
    noun_id: str
    name: str | None
    location: str | None
    aliases: tuple[str, ...]
    description: TextBlock | None
    tags: tuple[str, ...]
    state: dict[str, str | bool | int | float]
    portable: bool | None
    type_id: str | None
    exits: tuple[ExitDef, ...]
    verbs: tuple[VerbDef, ...]
    dialogue_entry: str | None
    dialogue_nodes: tuple[DialogueNode, ...]
    span: SourceSpan | None


@dataclass(frozen=True, slots=True)
class V1Rule:
    header: str
    statements: tuple[Statement, ...]
    span: SourceSpan


@dataclass(frozen=True, slots=True)
class V1Program:
    path: str
    rooms: tuple[V1Noun, ...]
    objects: tuple[V1Noun, ...]
    characters: tuple[V1Noun, ...]
    rules: tuple[V1Rule, ...]
    symbols: SymbolTable


def normalize_document(document: MuseDocument, symbols: SymbolTable) -> V1Program:
    """Convert the authored AST into the canonical V1 compiler IR."""

    return V1Program(
        path=document.path,
        rooms=tuple(_normalize_noun(noun) for noun in document.rooms),
        objects=tuple(_normalize_noun(noun) for noun in document.objects),
        characters=tuple(_normalize_noun(noun) for noun in document.characters),
        rules=tuple(V1Rule(rule.header, tuple(rule.statements), rule.span) for rule in document.rules),
        symbols=symbols,
    )


def _normalize_noun(noun: NounDef) -> V1Noun:
    return V1Noun(
        kind=noun.kind,
        noun_id=noun.noun_id,
        name=noun.name,
        location=noun.location,
        aliases=tuple(noun.aliases),
        description=noun.description,
        tags=tuple(noun.tags),
        state=dict(noun.state),
        portable=noun.portable,
        type_id=noun.type_id,
        exits=tuple(noun.exits),
        verbs=tuple(noun.verbs),
        dialogue_entry=noun.dialogue_entry,
        dialogue_nodes=tuple(noun.dialogue_nodes),
        span=noun.span,
    )

